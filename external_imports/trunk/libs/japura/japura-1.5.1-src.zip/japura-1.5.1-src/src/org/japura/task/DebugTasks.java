package org.japura.task;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

import org.japura.controller.ControllerModel;
import org.japura.debug.DebugComponent;
import org.japura.debug.DebugParameter;
import org.japura.debug.DebugResult;
import org.japura.gui.CheckComboBox;
import org.japura.gui.event.ListCheckListener;
import org.japura.gui.event.ListEvent;
import org.japura.gui.model.ListCheckModel;

/**
 * <P>
 * Copyright (C) 20112-2012 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 */
class DebugTasks extends DebugComponent{

  private static final long serialVersionUID = -387375942292452243L;

  private CheckComboBox eventComboBox;
  private CheckComboBox columnComboBox;
  private JPanel northPanel;
  private JButton clearButton;
  private JTable table;
  private List<TaskDebugLog> taskLogs;
  private List<Column> visibleColumns;
  private JList tasksList;

  private JSplitPane horizontalSplit;

  public DebugTasks() {
	visibleColumns = new ArrayList<Column>();
	ListCheckModel model = getColumnComboBox().getModel();
	for (Column column : Column.values()) {
	  model.addElement(column);
	  if (column.defaultEnabled) {
		model.addCheck(column);
		visibleColumns.add(column);
	  }
	}
	model.addListCheckListener(new ListCheckListener() {
	  @Override
	  public void removeCheck(ListEvent event) {
		updateVisibleColumns();
	  }

	  @Override
	  public void addCheck(ListEvent event) {
		updateVisibleColumns();
	  }

	  private void updateVisibleColumns() {
		visibleColumns.clear();
		for (Object obj : getColumnComboBox().getModel().getCheckeds()) {
		  visibleColumns.add((Column) obj);
		}
		getTable().tableChanged(null);
		getTable().repaint();
	  }

	});

	taskLogs = new ArrayList<TaskDebugLog>();
	setLayout(new BorderLayout());
	add(getHorizontalSplit(), BorderLayout.CENTER);
	add(getNorthPanel(), BorderLayout.NORTH);
  }

  private JSplitPane getHorizontalSplit() {
	if (horizontalSplit == null) {
	  horizontalSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);

	  JPanel panel = new JPanel();
	  panel.setLayout(new BorderLayout());
	  panel.add(new JLabel(" Tasks running: name [root controller]"),
		  BorderLayout.NORTH);
	  panel.add(new JScrollPane(getTasksList()), BorderLayout.CENTER);
	  add(panel, BorderLayout.EAST);
	  horizontalSplit.setLeftComponent(new JScrollPane(getTable()));
	  horizontalSplit.setRightComponent(panel);
	  // horizontalSplit.setDividerLocation(300);
	  horizontalSplit.setResizeWeight(1);
	}
	return horizontalSplit;
  }

  private JList getTasksList() {
	if (tasksList == null) {
	  tasksList = new JList();
	  tasksList.setModel(new DefaultListModel());
	}
	return tasksList;
  }

  private JTable getTable() {
	if (table == null) {
	  table = new JTable();
	  table.setModel(new Model());
	}
	return table;
  }

  private JPanel getNorthPanel() {
	if (northPanel == null) {
	  northPanel = new JPanel();
	  FlowLayout fl = new FlowLayout(FlowLayout.LEFT);
	  northPanel.setLayout(fl);
	  northPanel.add(new JLabel("Events:"));
	  northPanel.add(getEventComboBox());
	  northPanel.add(new JLabel("Columns:"));
	  northPanel.add(getColumnComboBox());
	  northPanel.add(getClearButton());
	}
	return northPanel;
  }

  private CheckComboBox getEventComboBox() {
	if (eventComboBox == null) {
	  eventComboBox = new CheckComboBox();
	  eventComboBox.setTextFor(CheckComboBox.NONE, "* any item selected *");
	  eventComboBox.setTextFor(CheckComboBox.MULTIPLE, "* multiple items *");
	  eventComboBox.setTextFor(CheckComboBox.ALL, "* all selected *");

	  ListCheckModel model = eventComboBox.getModel();
	  for (TaskEvent te : TaskEvent.values()) {
		model.addElement(te);
		model.addCheck(te);
	  }
	}
	return eventComboBox;
  }

  private CheckComboBox getColumnComboBox() {
	if (columnComboBox == null) {
	  columnComboBox = new CheckComboBox();
	  columnComboBox.setTextFor(CheckComboBox.NONE, "* any item selected *");
	  columnComboBox.setTextFor(CheckComboBox.MULTIPLE, "* multiple items *");
	  columnComboBox.setTextFor(CheckComboBox.ALL, "* all selected *");
	}
	return columnComboBox;
  }

  private JButton getClearButton() {
	if (clearButton == null) {
	  clearButton = new JButton("Clear");
	  clearButton.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
		  taskLogs.clear();
		  getTable().revalidate();
		}
	  });
	}
	return clearButton;
  }

  @Override
  protected String getTitle() {
	return "Tasks";
  }

  @Override
  protected DebugResult update(DebugParameter parameter) {
	if (parameter instanceof RemoveParameter) {
	  RemoveParameter rp = (RemoveParameter) parameter;
	  removeTask(rp.getTask());
	  return null;
	}

	if (parameter instanceof AddParameter) {
	  AddParameter ap = (AddParameter) parameter;
	  addTask(ap.getTask());
	  return null;
	}

	if (parameter instanceof AddParameterEvent) {
	  AddParameterEvent ape = (AddParameterEvent) parameter;
	  return addTask(ape.getTask(), ape.getEvent(), ape.getCurrentTime(),
		  ape.isEdt(), ape.getQueueCount());
	}

	return null;
  }

  private void addTask(final Task<?> task) {
	SwingUtilities.invokeLater(new Runnable() {
	  @Override
	  public void run() {
		DefaultListModel model = (DefaultListModel) getTasksList().getModel();
		model.addElement(new TaskItem(task));
	  }
	});
  }

  private void removeTask(final Task<?> task) {
	SwingUtilities.invokeLater(new Runnable() {
	  @Override
	  public void run() {
		DefaultListModel model = (DefaultListModel) getTasksList().getModel();
		model.removeElement(new TaskItem(task));
	  }
	});
  }

  public TaskDebugLog addTask(Task<?> task, TaskEvent event, long time,
							  boolean edt, int queueTasks) {
	if (getEventComboBox().getModel().isChecked(event) == false) {
	  return null;
	}

	final TaskDebugLog tl =
		new TaskDebugLog(task, event, time, edt, queueTasks);

	SwingUtilities.invokeLater(new Runnable() {
	  @Override
	  public void run() {
		taskLogs.add(tl);
		getTable().revalidate();
	  }
	});
	return tl;
  }

  private class Model implements TableModel{

	private Date date = new Date();

	@Override
	public int getRowCount() {
	  return taskLogs.size();
	}

	@Override
	public int getColumnCount() {
	  return visibleColumns.size();
	}

	@Override
	public String getColumnName(int columnIndex) {
	  Column column = visibleColumns.get(columnIndex);
	  return column.columnName;
	}

	@Override
	public Class<?> getColumnClass(int columnIndex) {
	  return String.class;
	}

	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
	  return false;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
	  Column column = visibleColumns.get(columnIndex);
	  TaskDebugLog tl = taskLogs.get(rowIndex);
	  if (column.equals(Column.ID)) {
		return tl.getId();
	  }
	  if (column.equals(Column.NAME)) {
		return tl.getName();
	  }
	  if (column.equals(Column.EVENT)) {
		return tl.getEvent();
	  }
	  if (column.equals(Column.QUEUE_TASKS)) {
		return Integer.toString(tl.getQueueTasks());
	  }
	  if (column.equals(Column.EDT)) {
		if (tl.isEdt()) {
		  return "yes";
		}
		return "no";
	  }
	  if (column.equals(Column.TIME_SPENT)) {
		if (tl.getEvent().equals(TaskEvent.DO_IN_BACKGROUND)) {
		  return tl.getTimeSpent();
		}
		return "";
	  }
	  if (column.equals(Column.WAIT_FOR_EDT)) {
		if (tl.isWaitForEDT()) {
		  return "yes";
		}
		return "no";
	  }
	  if (column.equals(Column.START_TIME)) {
		date.setTime(tl.getStartTime());
		return date.toString();
	  }
	  if (column.equals(Column.SOURCE)) {
		return tl.getSource();
	  }
	  return null;
	}

	@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {}

	@Override
	public void addTableModelListener(TableModelListener l) {}

	@Override
	public void removeTableModelListener(TableModelListener l) {}

  }

  private static enum Column {
	ID("Id", false),
	NAME("Name", true),
	EVENT("Event", true),
	QUEUE_TASKS("QueueTasks", false),
	EDT("EDT", false),
	TIME_SPENT("TimeSpent", false),
	WAIT_FOR_EDT("WaitForEDT", false),
	START_TIME("StartTime", false),
	SOURCE("Source", true);

	private boolean defaultEnabled;
	private String columnName;

	private Column(String name, boolean defaultEnabled) {
	  this.columnName = name;
	  this.defaultEnabled = defaultEnabled;
	}

	public String toString() {
	  return columnName;
	}
  }

  private static class TaskItem{
	private String id;
	private String name;

	public TaskItem(Task<?> task) {
	  this.id = task.getId();
	  this.name = task.getName();
	  if (this.name == null) {
		this.name = "---";
	  }
	  this.name = this.name.trim();

	  ControllerModel root = task.getRootModel();
	  if (root != null) {
		this.name += " [" + root.getClass().getSimpleName() + "]";
	  } else {
		this.name += " []";
	  }
	}

	@Override
	public int hashCode() {
	  final int prime = 31;
	  int result = 1;
	  result = prime * result + ((id == null) ? 0 : id.hashCode());
	  return result;
	}

	@Override
	public boolean equals(Object obj) {
	  if (this == obj)
		return true;
	  if (obj == null)
		return false;
	  if (getClass() != obj.getClass())
		return false;
	  TaskItem other = (TaskItem) obj;
	  if (id == null) {
		if (other.id != null)
		  return false;
	  } else if (!id.equals(other.id))
		return false;
	  return true;
	}

	@Override
	public String toString() {
	  return name;
	}
  }

  private static class Parameter extends DebugParameter{
	private Task<?> task;

	public Parameter(Task<?> task) {
	  this.task = task;
	}

	public Task<?> getTask() {
	  return task;
	}
  }

  static class AddParameter extends Parameter{
	public AddParameter(Task<?> task) {
	  super(task);
	}
  }

  static class RemoveParameter extends Parameter{
	public RemoveParameter(Task<?> task) {
	  super(task);
	}
  }

  static class AddParameterEvent extends Parameter{
	private long currentTime;
	private int queueCount;
	private TaskEvent event;
	private boolean edt;

	public AddParameterEvent(Task<?> task, TaskEvent event, long currentTime,
		boolean edt, int queueCount) {
	  super(task);
	  this.event = event;
	  this.queueCount = queueCount;
	  this.edt = edt;
	  this.currentTime = currentTime;
	}

	public long getCurrentTime() {
	  return currentTime;
	}

	public int getQueueCount() {
	  return queueCount;
	}

	public TaskEvent getEvent() {
	  return event;
	}

	public boolean isEdt() {
	  return edt;
	}

  }

}
