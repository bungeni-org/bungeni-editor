package org.japura.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.japura.task.Task;
import org.japura.task.TaskManager;

/**
 * <P>
 * Copyright (C) 2012 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 */
public abstract class AbstractController implements ControllerModel{

  static TokenKey tokenKey = new TokenKey();
  static AbstractController newParentController;

  private AbstractController parentController;
  private List<ControllerModel> childrenControllers;
  private List<MessageFilter> filters;
  private int id;
  private Group group;
  private boolean permanent;
  private boolean removed;
  private String controllerName;
  private String modalGroupName;

  AbstractController() {
	Lock.lock();
	try {
	  if (getClass().isAnnotationPresent(ChildController.class)
		  && newParentController == null) {
		throw new ControllerException(
			"["
				+ getClass().getName()
				+ "] Child controller must be instantiated through method createChild");
	  }
	  Class<?> cl = getClass();
	  if (cl.isAnnotationPresent(Singleton.class) && Controller.count(cl) > 0) {
		throw new ControllerException("[" + cl.getName()
			+ "] Singleton Controller");
	  }

	  parentController = newParentController;
	  childrenControllers = new ArrayList<ControllerModel>();
	  filters = new ArrayList<MessageFilter>();

	  this.id = Controller.getNextId();

	  if (parentController != null) {
		Group group = parentController.getGroup();
		this.group = group;
		parentController.addChild(this);
	  } else {
		Group group = new Group(getId());
		TaskManager.register(group, tokenKey);
		this.group = group;
	  }

	  Controller.add(this);
	  Controller.updateDebugComponents();
	} finally {
	  newParentController = null;
	  Lock.unlock();
	}
  }

  @Override
  public String stringToDebugComponent() {
	if (getControllerName() != null) {
	  return "Id:" + getId() + " - Name: " + getControllerName();
	}
	return "Id:" + getId();
  }

  protected void testControllerModel(Class<?> clss) {
	if (ControllerModel.class.isAssignableFrom(clss) == false) {
	  throw new InvalidControllerClassException(clss);
	}
  }

  @Override
  public final <E> E createChild(Class<E> cl) {
	Lock.lock();
	try {
	  testControllerModel(cl);
	  if (Controller.contains(this) == false) {
		throw new ControllerException("The controller " + getClass() + " id ("
			+ getId() + ") already had been removed from the pool. ");
	  }
	  Controller.newParentController = this;
	  return Controller.newInstance(cl);
	} finally {
	  Lock.unlock();
	}
  }

  @Override
  public <E> List<E> getChildren(Class<E> clss) {
	Lock.lock();
	try {
	  List<E> list = new ArrayList<E>();
	  for (ControllerModel controller : childrenControllers) {
		if (clss.isAssignableFrom(controller.getClass())) {
		  list.add(clss.cast(controller));
		}
	  }
	  return list;
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Indicates whether the child controller is instantiated.
   * 
   * @param clss
   *          controller's class
   * @return boolean
   */
  @Override
  public boolean isChildInstancied(Class<?> clss) {
	Lock.lock();
	try {
	  for (ControllerModel controller : childrenControllers) {
		if (clss.isAssignableFrom(controller.getClass())) {
		  return true;
		}
	  }
	  return false;
	} finally {
	  Lock.unlock();
	}
  }

  @Override
  public List<ControllerModel> getChildren() {
	Lock.lock();
	try {
	  return Collections.unmodifiableList(childrenControllers);
	} finally {
	  Lock.unlock();
	}
  }

  @Override
  public <E> E getChild(Class<E> clss) {
	Lock.lock();
	try {
	  for (ControllerModel controller : childrenControllers) {
		if (clss.isAssignableFrom(controller.getClass())) {
		  return clss.cast(controller);
		}
	  }
	  return null;
	} finally {
	  Lock.unlock();
	}
  }

  @Override
  public ControllerModel getChild(int id) {
	Lock.lock();
	try {
	  for (ControllerModel controller : childrenControllers) {
		if (controller.getId() == id) {
		  return controller;
		}
	  }
	  return null;
	} finally {
	  Lock.unlock();
	}
  }

  void addChild(ControllerModel controller) {
	this.childrenControllers.add(controller);
  }

  void removeChild(ControllerModel controller) {
	this.childrenControllers.remove(controller);
  }

  @Override
  public final int getId() {
	return id;
  }

  @Override
  public final Group getGroup() {
	return group;
  }

  /**
   * Indicates whether a controller is defined as permanent.
   * <P>
   * The state of permanent indicates that the controller can't be removed from
   * the memory, even if it used the removal methods.
   * 
   * @return boolean
   * @see #setPermanent(boolean)
   */
  @Override
  public final boolean isPermanent() {
	return permanent;
  }

  @Override
  public final int getGroupId() {
	return getGroup().getId();
  }

  @Override
  public String getModalGroupName() {
	return modalGroupName;
  }

  @Override
  public void setModalGroupName(String modalGroupName) {
	this.modalGroupName = modalGroupName;
  }

  @Override
  public String getControllerName() {
	return controllerName;
  }

  public void setControllerName(String controllerName) {
	this.controllerName = controllerName;
  }

  /**
   * Get the parent controller's identifier.
   * 
   * @return Integer the identifier or <CODE>NULL</CODE> if its not exist.
   */
  @Override
  public final Integer getParentId() {
	if (getParent() != null) {
	  return getParent().getId();
	}
	return null;
  }

  /**
   * Defines whether the controller is permanent.
   * <P>
   * The state of permanent indicates that the controller can't be removed from
   * the memory, even if it used the removal methods.
   * 
   * @param permanent
   * @see #isPermanent()
   */
  protected final void setPermanent(boolean permanent) {
	this.permanent = permanent;
  }

  protected <E> E getFromLink(Class<E> clss) {
	return Controller.getFromLink(this, clss);
  }

  /**
   * Link to other controller. <BR>
   * <BR>
   * The link is undone when one of the controllers is disposed. <BR>
   * <BR>
   * <ul>
   * Is not allowed:
   * <li>more than one link with a same controller.</li>
   * <li>link with two controllers from the same class</li>
   * </ul>
   * 
   * @param controller
   *          other controller
   * 
   * @see #hasLinkTo(Class)
   * @see #unlink()
   * @see #getFromLink(Class)
   */
  protected void linkTo(ControllerModel controller) {
	Controller.link(this, controller);
  }

  /**
   * Indicates whether the controller has a link to another controller from a
   * specific class.
   * 
   * @param clss
   *          the class from another controller
   * 
   * @return boolean
   * 
   * @see #linkTo(ControllerModel)
   * @see #unlink()
   * @see #getFromLink(Class)
   */
  protected boolean hasLinkTo(Class<?> clss) {
	return Controller.existsLink(this, clss);
  }

  /**
   * Indicates whether the controller has a link to another controller.
   * 
   * @param controller
   *          the other controller
   * 
   * @return boolean
   * 
   * @see #linkTo(ControllerModel)
   * @see #unlink()
   * @see #getFromLink(Class)
   */
  protected boolean hasLinkTo(ControllerModel controller) {
	return Controller.existsLink(this, controller);
  }

  /**
   * Undo the current link to any other controller.
   * 
   * @see #hasLinkTo(Class)
   * @see #getFromLink(Class)
   * @see #linkTo(ControllerModel)
   */
  protected void unlink() {
	Controller.unlink(this);
  }

  /**
   * Removes the controller from the memory. <BR>
   * <BR>
   * Undo, if exists, the current link to any other controller <BR>
   * <BR>
   * All task executions of the group will be canceled.
   */
  @Override
  public void free() {
	Controller.free(getId(), true);
  }

  /**
   * Removes the controller from the memory.
   * 
   * @param cancelTaskExecution
   */
  @Override
  public void free(boolean cancelTaskExecution) {
	Controller.free(getId(), cancelTaskExecution);
  }

  @Override
  public void freeGroup() {
	Controller.freeGroup(getGroupId());
  }

  /**
   * Indicates whether the controller has removed from the pool.
   * 
   * @return boolean
   */
  @Override
  public final boolean isRemoved() {
	return removed;
  }

  /**
   * Get the parent controller
   * 
   * @return the parent Controller or <CODE>NULL</CODE> if its not exist.
   */
  @Override
  public final ControllerModel getParent() {
	return parentController;
  }

  void clearParent() {
	parentController = null;
  }

  void setAsRemoved() {
	removed = true;
  }

  void clearChildren() {
	childrenControllers.clear();
  }

  @Override
  public final boolean isRoot() {
	if (getParent() == null) {
	  return true;
	}
	return false;
  }

  /**
   * Get the root controller in the hierarchy group.
   * 
   * @return the root controller in the hierarchy or the self controller if not
   *         exists a parent controller.
   */
  @Override
  public final ControllerModel getRoot() {
	ControllerModel superController = this;
	while (superController.getParent() != null) {
	  superController = superController.getParent();
	}
	return superController;
  }

  protected boolean canExecute(Task<?> task) {
	return true;
  }

  @Override
  public List<MessageFilter> getMessageFilters() {
	return Collections.unmodifiableList(filters);
  }

  protected void removeMessageFilters() {
	filters.clear();
  }

  protected void removeMessageFilter(MessageFilter filter) {
	if (filter != null) {
	  filters.remove(filter);
	}
  }

  protected boolean containsMessageFilter(MessageFilter filter) {
	if (filter != null) {
	  return filters.contains(filter);
	}
	return false;
  }

  protected void addMessageFilter(MessageFilter filter) {
	if (filter != null && filters.contains(filter) == false) {
	  filters.add(filter);
	}
  }

  @Override
  public final void publish(Message message) {
	message.setPublisher(this);
	Controller.publishToAll(message);
  }

  @Override
  public void subscribe(Message message) {}

  protected void beforeFreeController() {}

  protected void afterFreeController() {}

  @Override
  public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + id;
	return result;
  }

  @Override
  public boolean equals(Object obj) {
	if (this == obj)
	  return true;
	if (obj == null)
	  return false;
	if (getClass() != obj.getClass())
	  return false;
	AbstractController other = (AbstractController) obj;
	if (id != other.id)
	  return false;
	return true;
  }

  public final static class TokenKey{
	private TokenKey() {}
  }
}
