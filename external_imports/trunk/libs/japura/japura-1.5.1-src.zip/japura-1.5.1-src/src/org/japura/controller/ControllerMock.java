package org.japura.controller;

import java.awt.Component;
import java.awt.Window;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.japura.modal.ModalListener;
import org.japura.task.Task;
import org.japura.task.TaskSequence;

/**
 * <P>
 * Copyright (C) 2012 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 */
public class ControllerMock extends AbstractController{

  private List<ControllerMockListener> listeners;

  public ControllerMock() {
	listeners = new ArrayList<ControllerMockListener>();
  }

  private void methodNotImplemented() {
	throw new MockMethodNotImplementedException();
  }

  public void addListener(ControllerMockListener listener) {
	synchronized (listeners) {
	  listeners.add(listener);
	}
  }

  public synchronized void removeListener(ControllerMockListener listener) {
	synchronized (listeners) {
	  listeners.remove(listener);
	}
  }

  public synchronized List<ControllerMockListener> getListeners() {
	synchronized (listeners) {
	  return Collections.unmodifiableList(listeners);
	}
  }

  public final List<Task<?>> execute(TaskSequence taskSequence) {
	return execute(taskSequence.getFirstTask());
  }

  public final List<Task<?>> execute(Task<?> task) {
	List<Task<?>> list = new ArrayList<Task<?>>();
	execute(task, list);
	return list;
  }

  private void execute(Task<?> currentTask, List<Task<?>> list) {
	list.add(currentTask);
	currentTask.setRootModel(this);
	if (currentTask.isCanceled()) {
	  currentTask.canceled();
	  fireAfterTaskExecution(currentTask);
	} else {
	  try {
		currentTask.doInBackground();
	  } catch (Exception e) {
		currentTask.handleException(e);
	  }
	  currentTask.done();
	  fireAfterTaskExecution(currentTask);
	  for (Task<?> nextTask : currentTask.getNestedTasks()) {
		nextTask.setRootModel(currentTask.getRootModel());
		nextTask.setSession(currentTask.getSession());
		execute(nextTask, list);
	  }
	}
  }

  private synchronized void fireAfterTaskExecution(Task<?> task) {
	synchronized (listeners) {
	  for (ControllerMockListener listener : listeners) {
		listener.afterTaskExecution(task);
	  }
	}
  }

  @Override
  public boolean isComponentInstancied() {
	methodNotImplemented();
	return false;
  }

  @Override
  public void addModal(Component component) {
	methodNotImplemented();
  }

  @Override
  public void addModal(Component component, ModalListener listener) {
	methodNotImplemented();
  }

  @Override
  public void addModal(Component component, ModalListener listener,
					   Integer modalDepth) {
	methodNotImplemented();
  }

  @Override
  public void closeModal(Component component) {
	methodNotImplemented();
  }

  @Override
  public void closeAllModals() {
	methodNotImplemented();
  }

  @Override
  public boolean hasModal() {
	methodNotImplemented();
	return false;
  }

  @Override
  public void freeAfterExecutions() {
	methodNotImplemented();
  }

  @Override
  public Component getCurrentModal() {
	methodNotImplemented();
	return null;
  }

  @Override
  public boolean isFocused() {
	methodNotImplemented();
	return false;
  }

  @Override
  public void requestFocus() {
	methodNotImplemented();
  }

  @Override
  public boolean isWindowFocused() {
	methodNotImplemented();
	return false;
  }

  @Override
  public void requestWindowFocus() {
	methodNotImplemented();
  }

  @Override
  public Window getWindowAncestor() {
	methodNotImplemented();
	return null;
  }

  @Override
  public void showQuestionModal(String title, String question,
								ModalAction yesAction, ModalAction noAction) {
	methodNotImplemented();
  }

  @Override
  public void showQuestionModal(String title, String question,
								ModalAction yesAction) {
	methodNotImplemented();
  }

  @Override
  public void showConfirmationModal(String title, String question,
									ModalAction confirmAction,
									ModalAction cancelAction) {
	methodNotImplemented();
  }

  @Override
  public void showConfirmationModal(String title, String question,
									ModalAction confirmAction) {
	methodNotImplemented();
  }

  @Override
  public void showInformationModal(String title, String info) {
	methodNotImplemented();
  }

  @Override
  public void showWarningModal(String title, String warning) {
	methodNotImplemented();
  }

  @Override
  public void showErrorModal(String title, String error) {
	methodNotImplemented();
  }

}
