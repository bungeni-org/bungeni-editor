package org.japura.task.listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

import org.japura.task.Task;

/**
 * <P>
 * Copyright (C) 2012 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 */
public abstract class AbstractTaskExecutionListenerHandler implements
	TaskExecutionListenerHandler{

  private int delay = 600;
  private int groupId;
  private int count;
  private Starter starter;
  private InputEventBlocker eventHook = new InputEventBlocker();

  public AbstractTaskExecutionListenerHandler(int groupId) {
	this.groupId = groupId;
  }

  public void setDelay(int delay) {
	this.delay = delay;
  }

  public int getDelay() {
	return delay;
  }

  private Starter getStarter() {
	if (starter == null) {
	  starter = new Starter();
	}
	return starter;
  }

  protected abstract void initialize(Task<?> task);

  protected abstract void start();

  protected abstract void update(Task<?> task);

  protected abstract void finish(Task<?> task);

  @Override
  public void taskSubmitted(Task<?> task) {
	count++;
	if (count == 1) {
	  eventHook.apply();
	  initialize(task);
	  getStarter().start();
	}
  }

  public int getGroupId() {
	return groupId;
  }

  @Override
  public void beforeTaskExecute(Task<?> task) {
	update(task);
  }

  @Override
  public void afterTaskExecute(Task<?> task) {
	count--;
	if (count == 0) {
	  getStarter().stop();
	  eventHook.remove();
	  finish(task);
	}
  }

  private class Starter extends Timer implements ActionListener{

	private static final long serialVersionUID = 1L;
	private boolean stop;

	public Starter() {
	  super(AbstractTaskExecutionListenerHandler.this.getDelay(), null);
	  addActionListener(this);
	  setRepeats(false);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	  if (stop == false) {
		AbstractTaskExecutionListenerHandler.this.start();
		eventHook.remove();
	  }
	}

	@Override
	public void stop() {
	  stop = true;
	  super.stop();
	}
  }

}
