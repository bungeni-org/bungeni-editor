package org.japura.controller;

import java.awt.Component;
import java.awt.Window;
import java.util.List;

import org.japura.modal.ModalListener;

/**
 * <P>
 * Copyright (C) 2012 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 */
public interface ControllerModel{

  /**
   * Indicates whether the controller is instantiated.
   * 
   * @return boolean
   */
  public boolean isComponentInstancied();

  /**
   * Get the identifier.
   * 
   * @return the identifier
   */
  public int getId();
  
  public String stringToDebugComponent();

  /**
   * Shows a modal
   * 
   * @param component
   *          {@link Component}
   */
  public void addModal(Component component);

  public void addModal(Component component, ModalListener listener);

  public void addModal(Component component, ModalListener listener,
					   Integer modalDepth);

  /**
   * Close a modal
   * 
   * @param component
   *          the component's modal
   */
  public void closeModal(Component component);

  /**
   * Close all modals.
   */
  public void closeAllModals();

  /**
   * Indicates whether exists a modal.
   * 
   * @return boolean
   */
  public boolean hasModal();

  /**
   * Creates a child controller.
   * <P>
   * The new controller contains the parent controller's identifier.
   * 
   * @param <E>
   * @param clss
   *          the controller's class
   * @return the new controller
   * @see #getRoot()
   * @see #getParent()
   */
  public <E> E createChild(Class<E> clss);

  public void free();

  public void free(boolean cancelTaskExecution);

  public void freeGroup();

  public void freeAfterExecutions();

  public <E> E getChild(Class<E> clss);

  public ControllerModel getChild(int id);

  public void setModalGroupName(String modalGroupName);

  public String getModalGroupName();

  public Group getGroup();

  public int getGroupId();

  public Component getCurrentModal();

  public <E> List<E> getChildren(Class<E> clss);

  public List<ControllerModel> getChildren();

  public String getControllerName();

  public ControllerModel getParent();

  public Integer getParentId();

  public boolean isChildInstancied(Class<?> clss);

  public ControllerModel getRoot();

  public boolean isRoot();

  public boolean isPermanent();

  public boolean isFocused();

  public void requestFocus();

  public boolean isWindowFocused();

  public void requestWindowFocus();

  public Window getWindowAncestor();

  public void showQuestionModal(String title, String question,
								ModalAction yesAction, ModalAction noAction);

  public void showQuestionModal(String title, String question,
								ModalAction yesAction);

  public void showConfirmationModal(String title, String question,
									ModalAction confirmAction,
									ModalAction cancelAction);

  public void showConfirmationModal(String title, String question,
									ModalAction confirmAction);

  public void showInformationModal(String title, String info);

  public void showWarningModal(String title, String warning);

  public void showErrorModal(String title, String error);

  public void publish(Message message);

  public void subscribe(Message message);
  
  public boolean isRemoved();
  
  public List<MessageFilter> getMessageFilters();

}
