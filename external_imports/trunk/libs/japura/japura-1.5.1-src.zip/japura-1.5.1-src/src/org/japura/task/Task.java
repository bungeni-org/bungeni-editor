package org.japura.task;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.japura.controller.ControllerModel;
import org.japura.debug.DebugResult;
import org.japura.exception.HandlerExceptionManager;
import org.japura.exception.HandlerExceptionParameters;

/**
 * <P>
 * Copyright (C) 2011-2012 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 */
public class Task<T> implements Runnable{
  private static Random randomID = new Random();

  private CancelToken cancelToken;
  private ControllerModel rootControllerModel;
  private TaskSession session;
  private long threadId;
  private boolean submitted;
  private boolean asynchronous;
  private boolean hasException;
  private boolean executed;
  private boolean canceled;
  private Exception exception;
  private T result;
  private String name;
  private String message;
  private boolean waitForEDT = false;
  private String id;
  private boolean priority;
  private long backgroundTimeSpent;
  private List<Task<?>> nestedTasks;

  public Task() {
	int n1 = randomID.nextInt();
	long n2 = System.nanoTime();
	id = Long.toHexString(n1) + ":" + Long.toHexString(n2);
	nestedTasks = new ArrayList<Task<?>>();
	session = new TaskSession();
  }

  public void setSession(TaskSession session) {
	this.session = session;
  }

  public TaskSession getSession() {
	return session;
  }

  public <E> E getSession(Class<E> clss) {
	return clss.cast(session);
  }

  public synchronized final List<Task<?>> removeNestedTasks() {
	List<Task<?>> list = new ArrayList<Task<?>>(nestedTasks);
	nestedTasks.clear();
	return list;
  }

  public synchronized final List<Task<?>> getNestedTasks() {
	return Collections.unmodifiableList(nestedTasks);
  }

  protected synchronized final Task<?> addNestedTask(Task<?> task) {
	if (nestedTasks.contains(task) == false) {
	  nestedTasks.add(task);
	}
	return task;
  }

  void setBackgroundTimeSpent(long backgroundTimeSpent) {
	this.backgroundTimeSpent = backgroundTimeSpent;
  }

  public long getBackgroundTimeSpent() {
	return backgroundTimeSpent;
  }

  public final String getId() {
	return id;
  }

  void setCancelToken(CancelToken cancelToken) {
	this.cancelToken = cancelToken;
  }

  void clearCancelToken() {
	this.cancelToken = null;
  }

  void setHasException(boolean hasException) {
	this.hasException = hasException;
  }

  boolean hasException() {
	return hasException;
  }

  public void handleException(Exception e) {
	HashMap<String, Object> parameters = new HashMap<String, Object>();
	if (getRootModel() != null) {
	  Integer groupdId = getRootModel().getGroupId();
	  Integer controllerId = getRootModel().getId();
	  parameters.put(HandlerExceptionParameters.CONTROLLER_GROUP_ID, groupdId);
	  parameters.put(HandlerExceptionParameters.CONTROLLER_ID, controllerId);
	}

	HandlerExceptionManager.handle(getException(), parameters);
  }

  public final void setRootModel(ControllerModel controllerModel) {
	this.rootControllerModel = controllerModel;
  }

  public final ControllerModel getRootModel() {
	return rootControllerModel;
  }

  public final <E> E rootModelTo(Class<E> clss) {
	return clss.cast(getRootModel());
  }

  public String getName() {
	return name;
  }

  public void setName(String name) {
	this.name = name;
  }

  public String getMessage() {
	return message;
  }

  public void setMessage(String message) {
	this.message = message;
  }

  public boolean isWaitForEDT() {
	return waitForEDT;
  }

  public void setWaitForEDT(boolean waitForEDT) {
	this.waitForEDT = waitForEDT;
  }

  public void canceled() {}

  /**
   * Submits the task to the TaskManager.
   * <P>
   * Tasks can be submitted using: TaskManager.submit(task);
   */
  public void submit() {
	TaskManager.submit(this);
  }

  void setSubmitted(boolean submitted) {
	this.submitted = submitted;
  }

  public final boolean isSubmitted() {
	return submitted;
  }

  public void cancel() {
	if (isExecuted() == false) {
	  canceled = true;
	}
  }

  public T getResult() {
	return result;
  }

  protected void setResult(T result) {
	this.result = result;
  }

  long getThreadId() {
	return threadId;
  }

  void setCanceled(boolean canceled) {
	this.canceled = canceled;
  }

  public boolean isCanceled() {
	return canceled || (cancelToken != null && cancelToken.cancel);
  }

  void setThreadId(long threadId) {
	this.threadId = threadId;
  }

  protected void submitted() {}

  protected void willExecute() throws Exception {}

  public void done() {}

  void setExecuted() {
	if (isCanceled() == false) {
	  executed = true;
	}
  }

  public boolean isExecuted() {
	return executed;
  }

  public Exception getException() {
	return exception;
  }

  public void setException(Exception exception) {
	this.exception = exception;
  }

  public void retry() {
	if (hasException) {
	  setSubmitted(false);
	  setHasException(false);
	  setPriority();
	  submit();
	} else {
	  throw new TaskExeception("Task without exception");
	}
  }

  void setPriority() {
	priority = true;
  }

  boolean isPriority() {
	return priority;
  }

  void clearPriority() {
	priority = false;
  }

  public boolean isAsynchronous() {
	return asynchronous;
  }

  void setAsynchronous(boolean asynchronous) {
	this.asynchronous = asynchronous;
  }

  @Override
  public final void run() {
	if (isCanceled() || hasException()) {
	  return;
	}
	long s = System.currentTimeMillis();
	List<DebugResult> taskDebugLogs = null;
	try {
	  taskDebugLogs =
		  TaskManager.addToDebugWindow(this, TaskEvent.DO_IN_BACKGROUND);
	  doInBackground();
	} catch (Exception e) {
	  setHasException(true);
	  setException(e);
	} finally {
	  setBackgroundTimeSpent(System.currentTimeMillis() - s);
	  if (taskDebugLogs != null) {
		for (DebugResult dr : taskDebugLogs) {
		  if (dr instanceof TaskDebugLog) {
			TaskDebugLog tdl = (TaskDebugLog) dr;
			tdl.setTimeSpent(getBackgroundTimeSpent());
		  }
		}
	  }
	  setExecuted();
	}
  }

  public void doInBackground() throws Exception {}

  @Override
  public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((id == null) ? 0 : id.hashCode());
	return result;
  }

  @Override
  public boolean equals(Object obj) {
	if (this == obj)
	  return true;
	if (obj == null)
	  return false;
	if (getClass() != obj.getClass())
	  return false;
	Task<?> other = (Task<?>) obj;
	if (id == null) {
	  if (other.id != null)
		return false;
	} else if (!id.equals(other.id))
	  return false;
	return true;
  }

  @Override
  public String toString() {
	return getClass().getName() + "[" + getId() + "]";
  }

}
