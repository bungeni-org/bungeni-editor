package org.japura.task.listener;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.text.DecimalFormat;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.Border;

import org.japura.controller.Controller;
import org.japura.controller.ControllerModel;
import org.japura.gui.I18nStringKeys;
import org.japura.gui.WrapLabel;
import org.japura.i18n.I18nManager;
import org.japura.task.Task;

/**
 * <P>
 * Copyright (C) 2012 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 */
public class ModalProgressBarHandler extends
	AbstractTaskExecutionListenerHandler{

  private Icon progressBarIcon;
  private TaskExecutionModalPanel panel;

  public ModalProgressBarHandler(int groupId) {
	this(groupId, null);
  }

  public ModalProgressBarHandler(int groupId, Icon progressBarIcon) {
	super(groupId);
	this.progressBarIcon = progressBarIcon;
	if (this.progressBarIcon == null) {
	  URL url = getClass().getResource("/resources/images/jpr_progressbar.gif");
	  this.progressBarIcon = new ImageIcon(url);
	}
  }

  @Override
  protected void initialize(Task<?> task) {
	String text = task.getMessage();
	if (text == null) {
	  text = "";
	}
	panel = new TaskExecutionModalPanel(text, progressBarIcon);
  }

  @Override
  public void update(Task<?> task) {
	if (task.getMessage() != null) {
	  panel.setText(task.getMessage());
	}
  }

  @Override
  protected void finish(Task<?> task) {
	panel.stop();
	ControllerModel rootController = Controller.getRoot(getGroupId());
	if (rootController != null) {
	  rootController.closeModal(panel);
	}
	panel = null;
  }

  @Override
  protected void start() {
	ControllerModel controller = Controller.getRoot(getGroupId());
	if (controller != null) {
	  controller.addModal(panel, null, JLayeredPane.POPUP_LAYER + 1);
	  panel.start();
	}
  }

  private static class TaskExecutionModalPanel extends JPanel{

	private static final long serialVersionUID = -8882308898730194272L;
	private WrapLabel label;
	private JLabel timerLabel;
	private long elapsedStartTime = 0;
	private DecimalFormat integerTimeFormatter;
	private int width = 300;
	private String text;
	private StringBuilder textTimer;
	private Timer timer;

	public TaskExecutionModalPanel(String text, Icon progressBarIcon) {
	  textTimer = new StringBuilder();
	  integerTimeFormatter = new DecimalFormat("00");
	  if (text == null) {
		text = "";
	  }
	  this.text = text;

	  Border out = BorderFactory.createLineBorder(Color.BLACK, 2);
	  Border in = BorderFactory.createEmptyBorder(8, 8, 8, 8);
	  setBorder(BorderFactory.createCompoundBorder(out, in));
	  setBackground(Color.WHITE);
	  setLayout(new GridBagLayout());

	  GridBagConstraints gbc = new GridBagConstraints();
	  gbc.gridx = 0;
	  gbc.gridy = 0;
	  gbc.anchor = GridBagConstraints.NORTHWEST;
	  gbc.weighty = 1;
	  gbc.weightx = 1;
	  add(getLabel(), gbc);

	  gbc.insets = new Insets(20, 0, 0, 0);
	  gbc.gridx = 0;
	  gbc.gridy = 1;
	  gbc.anchor = GridBagConstraints.SOUTH;
	  gbc.weighty = 1;
	  gbc.weightx = 1;

	  add(getTimeLabel(), gbc);

	  gbc.insets = new Insets(0, 0, 0, 0);
	  gbc.gridx = 0;
	  gbc.gridy = 2;
	  gbc.anchor = GridBagConstraints.CENTER;
	  gbc.weightx = 1;

	  JLabel progressBar = new JLabel(progressBarIcon);
	  progressBar.setName("progressComponent");
	  add(progressBar, gbc);
	}

	public void setText(String text) {
	  getLabel().setText(text);
	}

	private JLabel getTimeLabel() {
	  if (timerLabel == null) {
		timerLabel = new JLabel();
		timerLabel.setName("timerLabel");
		timerLabel.setText(getTimerString(0));
	  }
	  return timerLabel;
	}

	protected Timer getTimer() {
	  if (timer == null) {
		timer = new Timer(1000, new ActionListener() {
		  @Override
		  public void actionPerformed(ActionEvent e) {
			long seconds = System.currentTimeMillis() - elapsedStartTime;
			getTimeLabel().setText(getTimerString(seconds));
		  }
		});
	  }
	  return timer;
	}

	public void start() {
	  elapsedStartTime = System.currentTimeMillis();
	  getTimer().start();
	}

	public void stop() {
	  getTimer().stop();
	}

	private WrapLabel getLabel() {
	  if (label == null) {
		label = new WrapLabel(text);
		label.setWrapWidth(width);
		label.setName("messageLabel");
	  }
	  return label;
	}

	private String getTimerString(long seconds) {
	  if (seconds < 0) {
		return "-";
	  }
	  seconds = seconds / 1000L;

	  textTimer.setLength(0);
	  textTimer.append(I18nManager.getString(I18nStringKeys.TIME_ELAPSED
		  .getKey()));
	  textTimer.append(" ");

	  long sec = seconds;
	  long min = 0;
	  long hou = 0;
	  if (sec >= 60) {
		min = (int) sec / 60;
		sec = sec - (min * 60);
	  }
	  if (min >= 60) {
		hou = (int) min / 60;
		min = min - (hou * 60);
	  }
	  textTimer.append(integerTimeFormatter.format(hou));
	  textTimer.append(I18nManager.getString(I18nStringKeys.HOUR_ACRONYM
		  .getKey()));
	  textTimer.append(" ");
	  textTimer.append(integerTimeFormatter.format(min));
	  textTimer.append(I18nManager.getString(I18nStringKeys.MINUTE_ACRONYM
		  .getKey()));
	  textTimer.append(" ");
	  textTimer.append(integerTimeFormatter.format(sec));
	  textTimer.append(I18nManager.getString(I18nStringKeys.SECOND_ACRONYM
		  .getKey()));

	  return textTimer.toString();
	}

  }

}
