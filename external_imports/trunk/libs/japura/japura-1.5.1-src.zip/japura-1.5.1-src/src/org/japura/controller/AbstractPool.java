package org.japura.controller;

import java.awt.Component;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.japura.task.TaskManager;

/**
 * <P>
 * Copyright (C) 2012 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 */
abstract class AbstractPool{

  static ControllerMockFactory controllerMockFactory;
  static Random idRandom = new Random();

  ArrayList<ControllerModel> controllers;
  private List<Link> links;
  private List<PoolListener> listeners;

  AbstractPool() {
	controllers = new ArrayList<ControllerModel>();
	links = new ArrayList<Link>();
	listeners = new ArrayList<PoolListener>();
  }

  public final void addListener(PoolListener listener) {
	synchronized (listeners) {
	  listeners.add(listener);
	}
  }

  public final void removeListener(PoolListener listener) {
	synchronized (listeners) {
	  listeners.remove(listener);
	}
  }

  public final List<PoolListener> getListeners() {
	synchronized (listeners) {
	  return Collections.unmodifiableList(listeners);
	}
  }

  final void methodNotImplemented() {
	throw new MockMethodNotImplementedException();
  }

  final void testControllerModel(Class<?> clss) {
	if (ControllerModel.class.isAssignableFrom(clss) == false) {
	  throw new InvalidControllerClassException(clss);
	}
  }

  final boolean existsLink(ControllerModel controller1,
						   ControllerModel controller2) {
	if (controller1 == null || controller2 == null) {
	  return false;
	}

	for (Link link : links) {
	  if (link.contains(controller1) && link.contains(controller2)) {
		return true;
	  }
	}
	return false;
  }

  final boolean existsLink(ControllerModel controller, Class<?> clss) {
	testControllerModel(clss);

	if (controller == null || clss == null
		|| controller.getClass().equals(clss)) {
	  return false;
	}

	for (Link link : links) {
	  if (link.contains(controller) && link.contains(clss)) {
		return true;
	  }
	}
	return false;
  }

  final void link(ControllerModel controller1, ControllerModel controller2) {
	if (controller1 == null || controller2 == null) {
	  throw new ControllerException("Null controller");
	}
	if (controller1.getClass().equals(controller2.getClass())) {
	  throw new ControllerException(
		  "Can not link two controllers from the same class");
	}
	if (controller1.equals(controller2)) {
	  throw new ControllerException("Can not link the same controller");
	}

	for (Link link : links) {
	  if (link.contains(controller1)) {
		throw new ControllerException("Already exists a link for "
			+ controller1.getClass().getName() + " [" + controller1.getId()
			+ "]");
	  }
	  if (link.contains(controller2)) {
		throw new ControllerException("Already exists a link for "
			+ controller2.getClass().getName() + " [" + controller2.getId()
			+ "]");
	  }
	}
	links.add(new Link(controller1, controller2));
  }

  final void unlink(ControllerModel controller1, ControllerModel controller2) {
	if (controller1 == null || controller2 == null) {
	  return;
	}
	if (controller1.getClass().equals(controller2.getClass())) {
	  return;
	}
	if (controller1.equals(controller2)) {
	  return;
	}
	Link link = null;
	for (Link l : links) {
	  if (l.contains(controller1) && l.contains(controller2)) {
		link = l;
		break;
	  }
	}
	if (link != null) {
	  links.remove(link);
	}
  }

  final void remove(int id) {
	remove(id, true);
  }

  final void remove(int id, boolean cancelTaskExecution) {
	for (ControllerModel controller : controllers) {
	  if (controller.getId() == id) {
		remove(controller, cancelTaskExecution);
		break;
	  }
	}
  }

  final void removeGroup(int groupdId) {
	List<Integer> ids = new ArrayList<Integer>();
	for (ControllerModel controller : controllers) {
	  if (controller.getGroupId() == groupdId) {
		ids.add(controller.getId());
	  }
	}
	for (int id : ids) {
	  remove(id);
	}
  }

  final void removeAll(Class<?> clss) {
	testControllerModel(clss);
	synchronized (listeners) {
	  for (PoolListener listener : listeners) {
		listener.attemptToRemove(clss);
	  }
	}
	List<Integer> ids = new ArrayList<Integer>();
	for (ControllerModel controller : controllers) {
	  if (clss.isAssignableFrom(controller.getClass())) {
		ids.add(controller.getId());
	  }
	}
	for (int id : ids) {
	  remove(id);
	}
  }

  final void removeAllFromGroup(int groupId, Class<?> clss) {
	testControllerModel(clss);
	synchronized (listeners) {
	  for (PoolListener listener : listeners) {
		listener.attemptToRemove(groupId, clss);
	  }
	}
	List<Integer> ids = new ArrayList<Integer>();
	for (ControllerModel controller : controllers) {
	  if (controller.getGroupId() == groupId
		  && clss.isAssignableFrom(controller.getClass())) {
		ids.add(controller.getId());
	  }
	}
	for (int id : ids) {
	  remove(id);
	}
  }

  final boolean isInstancied(Class<?> clss) {
	testControllerModel(clss);
	for (ControllerModel controller : controllers) {
	  if (clss.isAssignableFrom(controller.getClass())) {
		return true;
	  }
	}
	return false;
  }

  final boolean isInstanciedInGroup(int groupId, Class<?> clss) {
	testControllerModel(clss);
	for (ControllerModel controller : controllers) {
	  if (controller.getGroupId() == groupId
		  && clss.isAssignableFrom(controller.getClass())) {
		return true;
	  }
	}
	return false;
  }

  final void removeAll() {
	List<Integer> ids = new ArrayList<Integer>();
	for (ControllerModel controller : controllers) {
	  ids.add(controller.getId());
	}
	for (int id : ids) {
	  remove(id);
	}
  }

  final int count(Class<?> clss) {
	testControllerModel(clss);

	int count = 0;
	for (ControllerModel controller : controllers) {
	  if (clss.isAssignableFrom(controller.getClass())) {
		count++;
	  }
	}
	return count;
  }

  final <E> E get(Class<E> clss) {
	testControllerModel(clss);

	ChildController cc = clss.getAnnotation(ChildController.class);
	if (cc != null && cc.getOnlyFromGroup()) {
	  throw new ControllerException(
		  "You need get the child controller "
			  + clss.getName()
			  + " through the group. Use getGroup().get() or Controller.getFromGroup() method.");
	}

	for (ControllerModel controller : controllers) {
	  if (clss.isAssignableFrom(controller.getClass())) {
		return clss.cast(controller);
	  }
	}
	return newInstance(clss);
  }

  abstract Class<?> getNewInstanceClass();

  final <E> E newInstance(Class<E> clss) {
	E controller = null;
	if (getNewInstanceClass().isAssignableFrom(clss)) {
	  try {
		if (controllerMockFactory != null) {
		  controller = controllerMockFactory.create(clss);
		} else {
		  controller = clss.newInstance();
		}
	  } catch (Exception e) {
		e.printStackTrace();
		Controller.newParentController = null;
		throw new RuntimeException(e);
	  }
	} else {
	  Controller.newParentController = null;
	  throw new InvalidControllerClassException(clss);
	}
	return controller;
  }

  final <E> E get(int id, Class<E> clss) {
	testControllerModel(clss);
	for (ControllerModel controller : controllers) {
	  if (controller.getId() == id
		  && clss.isAssignableFrom(controller.getClass())) {
		return clss.cast(controller);
	  }
	}
	return null;
  }

  final <E> E getFromGroup(int groupId, Class<E> clss) {
	testControllerModel(clss);
	for (ControllerModel controller : controllers) {
	  if (controller.getGroupId() == groupId
		  && clss.isAssignableFrom(controller.getClass())) {
		return clss.cast(controller);
	  }
	}
	return null;
  }

  final <E> E getFromGroup(int groupId, int id, Class<E> clss) {
	testControllerModel(clss);
	for (ControllerModel controller : controllers) {
	  if (controller.getGroupId() == groupId && controller.getId() == id
		  && clss.isAssignableFrom(controller.getClass())) {
		return clss.cast(controller);
	  }
	}
	return null;
  }

  final ControllerModel getFromGroup(int groupId, int id) {
	for (ControllerModel controller : controllers) {
	  if (controller.getGroupId() == groupId && controller.getId() == id) {
		return controller;
	  }
	}
	return null;
  }

  final <E> List<E> getAllFromGroup(int groupId, Class<E> clss) {
	testControllerModel(clss);
	List<E> list = new ArrayList<E>();
	for (ControllerModel controller : controllers) {
	  if (controller.getGroupId() == groupId
		  && clss.isAssignableFrom(controller.getClass())) {
		list.add(clss.cast(controller));
	  }
	}
	return list;
  }

  final List<ControllerModel> getAllFromGroup(int groupId) {
	List<ControllerModel> list = new ArrayList<ControllerModel>();
	for (ControllerModel controller : controllers) {
	  if (controller.getGroupId() == groupId) {
		list.add(controller);
	  }
	}
	return list;
  }

  final ControllerModel get(int id) {
	for (ControllerModel controller : controllers) {
	  if (controller.getId() == id) {
		return controller;
	  }
	}
	return null;
  }

  final <E> List<E> getAll(Class<E> clss) {
	testControllerModel(clss);
	List<E> list = new ArrayList<E>();
	for (ControllerModel controller : controllers) {
	  if (clss.isAssignableFrom(controller.getClass())) {
		list.add(clss.cast(controller));
	  }
	}
	return list;
  }

  final List<ControllerModel> getAll() {
	return new ArrayList<ControllerModel>(controllers);
  }

  final boolean contains(ControllerModel controller) {
	if (controller.isRemoved()) {
	  return false;
	}
	return controllers.contains(controller);
  }

  final void printAllControllers() {
	for (ControllerModel controller : controllers) {
	  System.out.println("Id: " + controller.getId() + " GroupId: "
		  + controller.getGroupId() + " Class: "
		  + controller.getClass().getName());
	}
  }

  final ControllerModel getRoot(int groupId) {
	for (ControllerModel controller : controllers) {
	  if (controller.getGroupId() == groupId) {
		return controller.getRoot();
	  }
	}
	return null;
  }

  final <E> E getFromLink(ControllerModel controllerInLink, Class<E> clss) {
	testControllerModel(clss);
	if (controllerInLink == null || clss == null) {
	  return null;
	}
	if (controllerInLink.getClass().equals(clss)) {
	  return null;
	}

	for (Link link : links) {
	  if (link.contains(controllerInLink)) {
		return link.get(clss);
	  }
	}
	return null;
  }

  private final void remove(ControllerModel controller,
							boolean cancelTaskExecution) {
	if (controller != null && controller.isPermanent() == false) {
	  boolean isRoot = controller.isRoot();

	  List<ControllerModel> children = new ArrayList<ControllerModel>();
	  fetchHierarchy(controller, children);

	  AbstractController c = (AbstractController) controller;

	  c.beforeFreeController();
	  for (ControllerModel child : children) {
		Controller<?> cc = (Controller<?>) child;
		cc.beforeFreeController();
	  }

	  Integer groupId = controller.getGroupId();
	  if (cancelTaskExecution) {
		TaskManager.cancel(groupId);
	  }

	  closeModal(controller);
	  for (ControllerModel child : children) {
		closeModal(child);
	  }

	  AbstractController parentController = (AbstractController) controller.getParent();
	  if (parentController != null) {
		parentController.removeChild(c);
	  }

	  c.clearParent();
	  c.clearChildren();
	  for (ControllerModel child : children) {
		Controller<?> cc = (Controller<?>) child;
		cc.clearParent();
		cc.clearChildren();
	  }

	  controllers.remove(controller);
	  c.setAsRemoved();
	  unlink(controller);
	  if (isRoot) {
		// group free
		Group group = controller.getGroup();
		TaskManager.unregister(group, AbstractController.tokenKey);
	  }
	  removeFromDebugComponents(c);
	  for (ControllerModel child : children) {
		Controller<?> cc = (Controller<?>) child;
		controllers.remove(child);
		cc.setAsRemoved();
		unlink(child);
		removeFromDebugComponents(cc);
	  }

	  c.afterFreeController();
	  for (ControllerModel child : children) {
		Controller<?> cc = (Controller<?>) child;
		cc.afterFreeController();
	  }

	  updateDebugComponents();
	  synchronized (listeners) {
		for (PoolListener listener : listeners) {
		  listener.removed(controller);
		}
	  }
	}
  }

  abstract void closeModal(ControllerModel model);

  abstract void updateDebugComponents();

  abstract void removeFromDebugComponents(ControllerModel controller);

  final int getNextId() {
	int nextId;
	do {
	  nextId = idRandom.nextInt(Integer.MAX_VALUE);
	} while (get(nextId) != null);
	return nextId;
  }

  final void unlink(ControllerModel controller) {
	Link link = null;
	for (Link l : links) {
	  if (l.contains(controller)) {
		link = l;
		break;
	  }
	}
	if (link != null) {
	  links.remove(link);
	}
  }

  final void fetchHierarchy(ControllerModel parentController,
							List<ControllerModel> list) {
	List<ControllerModel> children = parentController.getChildren();
	for (ControllerModel child : children) {
	  ControllerModel c = (ControllerModel) child;
	  list.add(c);
	  fetchHierarchy(c, list);
	}
  }

  final void add(ControllerModel controller) {
	controllers.add(controller);
	synchronized (listeners) {
	  for (PoolListener listener : listeners) {
		listener.added(controller);
	  }
	}
  }

  final void publishToAll(Message message) {
	for (ControllerModel controller : getAll()) {
	  if (message.isConsumed()) {
		break;
	  }
	  if (message.getPublisher() != null && message.isIgnorePublisher()
		  && message.getPublisher().getId() == controller.getId()) {
		continue;
	  }
	  if (acceptsMessage(controller, message)
		  && message.acceptsController(controller)) {
		controller.subscribe(message);
	  }
	}
  }

  private boolean acceptsMessage(ControllerModel controller, Message message) {
	for (MessageFilter filter : controller.getMessageFilters()) {
	  if (filter.accepts(message) == false) {
		return false;
	  }
	}
	return true;
  }

  abstract <E> E get(Class<E> clss, Component comp);

  abstract ControllerModel get(Component comp);

}
