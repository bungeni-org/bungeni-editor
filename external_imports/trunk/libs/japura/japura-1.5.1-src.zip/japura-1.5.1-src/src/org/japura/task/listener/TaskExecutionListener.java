package org.japura.task.listener;

import java.util.HashMap;

import org.japura.controller.Controller;
import org.japura.task.Task;
import org.japura.task.TaskManagerListener;

/**
 * <P>
 * Copyright (C) 2012 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 */
public abstract class TaskExecutionListener implements TaskManagerListener{

  private HashMap<Integer, Integer> tasksCount;
  private int globalTasksCount;

  private TaskExecutionListenerHandler globalHandler = null;
  private HashMap<Integer, TaskExecutionListenerHandler> groupHandlers;

  public TaskExecutionListener() {
	groupHandlers = new HashMap<Integer, TaskExecutionListenerHandler>();
	tasksCount = new HashMap<Integer, Integer>();
  }

  @Override
  public synchronized void submitted(Task<?> task) {
	if (task.isCanceled()) {
	  return;
	}

	TaskExecutionListenerHandler handler = null;

	Controller<?> controller = getController(task);
	if (controller != null) {
	  Integer groupId = controller.getGroupId();

	  Integer count = tasksCount.get(groupId);
	  if (count == null) {
		count = 0;
	  }
	  count++;
	  tasksCount.put(groupId, count);

	  handler = groupHandlers.get(groupId);
	  if (handler == null) {
		handler = buildGroupHandler(groupId, task);
		if (handler != null) {
		  groupHandlers.put(groupId, handler);
		}
	  }
	} else {
	  globalTasksCount++;
	  if (globalHandler == null) {
		globalHandler = buildGlobalHandler(task);
	  }
	  handler = globalHandler;
	}

	if (handler != null) {
	  handler.taskSubmitted(task);
	}
  }

  @Override
  public synchronized void beforeExecute(Task<?> task) {
	TaskExecutionListenerHandler handler = null;

	Controller<?> controller = getController(task);
	if (controller != null) {
	  Integer groupId = controller.getGroupId();
	  handler = groupHandlers.get(groupId);
	} else {
	  handler = globalHandler;
	}

	if (handler != null) {
	  handler.beforeTaskExecute(task);
	}
  }

  @Override
  public synchronized void afterExecute(Task<?> task) {
	TaskExecutionListenerHandler handler = null;

	Controller<?> controller = getController(task);
	if (controller != null) {
	  Integer groupId = controller.getGroupId();
	  handler = groupHandlers.get(groupId);

	  Integer count = tasksCount.get(groupId);
	  count--;
	  if (count == 0) {
		tasksCount.remove(groupId);
		groupHandlers.remove(groupId);
	  } else {
		tasksCount.put(groupId, count);
	  }
	} else {
	  handler = globalHandler;
	  globalTasksCount--;
	  if (globalTasksCount == 0) {
		globalHandler = null;
	  }
	}

	if (handler != null) {
	  handler.afterTaskExecute(task);
	}
  }

  private Controller<?> getController(Task<?> task) {
	if (task.getRootModel() != null) {
	  Controller<?> c = task.rootModelTo(Controller.class);
	  if (c != null && Controller.contains(c)) {
		return c;
	  }
	}
	return null;
  }

  protected abstract TaskExecutionListenerHandler buildGlobalHandler(Task<?> task);

  protected abstract TaskExecutionListenerHandler buildGroupHandler(int groupId,
																	Task<?> task);

}
