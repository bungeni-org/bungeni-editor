package org.japura.task;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.RunnableFuture;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.swing.SwingUtilities;

import org.japura.controller.ControllerModel;

/**
 * <P>
 * Copyright (C) 2011-2012 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 */
abstract class AbstractTaskExecutor extends ThreadPoolExecutor{

  private CancelToken cancelToken;
  private List<Task<?>> tasks = new ArrayList<Task<?>>();

  protected AbstractTaskExecutor(int corePoolSize, int maximumPoolSize,
	  long keepAliveTime, TimeUnit unit, BlockingQueue<Runnable> workQueue) {
	super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue);
  }

  synchronized void cancel() {
	if (cancelToken != null) {
	  cancelToken.cancel = true;
	  cancelToken = null;
	}
  }

  synchronized CancelToken getCancelToken() {
	if (cancelToken == null) {
	  cancelToken = new CancelToken();
	}
	return cancelToken;
  }

  @Override
  protected final <T> RunnableFuture<T> newTaskFor(Runnable runnable, T value) {
	Task<?> task = (Task<?>) runnable;
	tasks.add(task);
	return new FutureTaskWrapper<T>(task, value);
  }

  @Override
  protected final void beforeExecute(Thread t, Runnable r) {
	FutureTaskWrapper<?> ftw = (FutureTaskWrapper<?>) r;
	Task<?> task = ftw.getTask();
	beforeExecute(task);
  }

  final boolean hasTask() {
	return tasks.size() > 0;
  }

  protected List<Task<?>> removeTasks() {
	List<Task<?>> list = new ArrayList<Task<?>>();
	for (Task<?> task : tasks) {
	  list.add(task);
	}
	tasks.clear();
	return list;
  }

  final boolean hasTask(int controllerGroupId) {
	for (Task<?> task : tasks) {
	  ControllerModel controller = task.getRootModel();
	  if (controller != null) {
		if (controller.getGroupId() == controllerGroupId) {
		  return true;
		}
	  }
	}
	return false;
  }

  abstract void beforeExecute(Task<?> task);

  @Override
  protected final void afterExecute(Runnable r, Throwable t) {
	FutureTaskWrapper<?> ftw = (FutureTaskWrapper<?>) r;
	Task<?> task = ftw.getTask();
	tasks.remove(task);

	List<Task<?>> nestedTasks = task.removeNestedTasks();
	for (int i = nestedTasks.size() - 1; i >= 0; i--) {
	  Task<?> nestedTask = nestedTasks.get(i);
	  nestedTask.setPriority();
	  nestedTask.setSubmitted(false);
	  nestedTask.setRootModel(task.getRootModel());
	  nestedTask.setSession(task.getSession());
	  if (nestedTask.getMessage() == null) {
		nestedTask.setMessage(task.getMessage());
	  }
	  if (task.hasException()) {
		nestedTask.cancel();
	  } else {
		nestedTask.setCanceled(false);
	  }
	  nestedTask.submit();
	}
	TaskManager.checkAndClean(task);
	afterExecute(task);
  }

  protected abstract void afterExecute(final Task<?> task);

  protected abstract boolean isWaitForEDT(Task<?> task);

  protected void applyAfterExecute(final Task<?> task) {
	Runnable runnable = null;
	if (task.hasException()) {
	  runnable = new Runnable() {
		@Override
		public void run() {
		  TaskManager.addToDebugWindow(task, TaskEvent.ERROR);
		  task.handleException(task.getException());
		}
	  };
	} else if (task.isExecuted()) {
	  runnable = new Runnable() {
		@Override
		public void run() {
		  TaskManager.addToDebugWindow(task, TaskEvent.DONE);
		  task.done();
		}
	  };
	} else if (task.isCanceled()) {
	  runnable = new Runnable() {
		@Override
		public void run() {
		  TaskManager.addToDebugWindow(task, TaskEvent.CANCELED);
		  task.canceled();
		}
	  };
	}

	if (runnable == null) {
	  return;
	}

	if (isWaitForEDT(task)) {
	  try {
		SwingUtilities.invokeAndWait(runnable);
	  } catch (InterruptedException e) {
		e.printStackTrace();
	  } catch (InvocationTargetException e) {
		e.printStackTrace();
	  }
	} else {
	  SwingUtilities.invokeLater(runnable);
	}
  }
}
