package org.japura.controller;

import java.awt.Component;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;

import org.japura.debug.DebugComponent;
import org.japura.modal.Modal;

/**
 * <P>
 * Copyright (C) 2012 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 */
class ControllerPool extends AbstractPool{

  @Override
  void closeModal(ControllerModel model) {
	Controller<?> controller = (Controller<?>) model;
	if (controller.isComponentInstancied()) {
	  Component component = controller.getComponent();
	  if (component != null) {
		if (component instanceof JFrame) {
		  JFrame frame = (JFrame) component;
		  Modal.closeAllModals(frame);
		} else if (component instanceof JDialog) {
		  JDialog dialog = (JDialog) component;
		  Modal.closeAllModals(dialog);
		} else if (component instanceof JInternalFrame) {
		  JInternalFrame frame = (JInternalFrame) component;
		  Modal.closeAllModals(frame);
		}
	  }
	}
  }

  @Override
  void removeFromDebugComponents(ControllerModel model) {
	Controller<?> controller = (Controller<?>) model;
	if (DebugComponent.exists(DebugControllers.class)) {
	  DebugControllers.Parameter parameter =
		  new DebugControllers.Parameter(controller);
	  DebugComponent.publish(DebugControllers.class, parameter);
	}
  }

  @Override
  void updateDebugComponents() {
	if (DebugComponent.exists(DebugControllers.class)) {
	  DebugControllers.Parameter parameter = new DebugControllers.Parameter();
	  DebugComponent.publish(DebugControllers.class, parameter);
	}
  }

  @Override
  <E> E get(Class<E> clss, Component comp) {
	testControllerModel(clss);
	for (ControllerModel controller : controllers) {
	  Controller<?> c = (Controller<?>) controller;
	  if (clss.isAssignableFrom(controller.getClass())
		  && controller.isComponentInstancied()
		  && c.getComponent().equals(comp)) {
		return clss.cast(controller);
	  }
	}
	return null;
  }

  @Override
  ControllerModel get(Component comp) {
	for (ControllerModel controller : controllers) {
	  Controller<?> c = (Controller<?>) controller;
	  if (controller.isComponentInstancied() && c.getComponent().equals(comp)) {
		return controller;
	  }
	}
	return null;
  }

  @Override
  Class<?> getNewInstanceClass() {
	return Controller.class;
  }

}
