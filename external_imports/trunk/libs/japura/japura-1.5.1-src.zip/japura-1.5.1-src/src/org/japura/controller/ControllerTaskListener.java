package org.japura.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.japura.task.Task;
import org.japura.task.TaskManager;
import org.japura.task.TaskManagerListener;

/**
 * <P>
 * Copyright (C) 2011-2012 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 */
class ControllerTaskListener implements TaskManagerListener{

  private static ControllerTaskListener instance;

  public static ControllerTaskListener getInstance() {
	if (instance == null) {
	  instance = new ControllerTaskListener();
	}
	return instance;
  }

  private HashMap<String, Integer> freeAfterExecution;
  private List<Integer> freeAfterAllExecutions;

  private ControllerTaskListener() {
	freeAfterExecution = new HashMap<String, Integer>();
	freeAfterAllExecutions = new ArrayList<Integer>();
  }

  public synchronized void freeAfterExecution(Controller<?> controller,
											  Task<?> task) {
	Integer controllerId = controller.getId();
	String taskId = task.getId();
	freeAfterExecution.put(taskId, controllerId);
  }

  public synchronized void freeAfterAllExecutions(Controller<?> controller) {
	Integer id = controller.getId();
	freeAfterAllExecutions.add(id);
  }

  @Override
  public void submitted(Task<?> task) {}

  @Override
  public void beforeExecute(Task<?> task) {}

  @Override
  public synchronized void afterExecute(Task<?> task) {
	ControllerModel controller = task.getRootModel();
	if (controller == null) {
	  return;
	}
	Group group = controller.getGroup();
	if (TaskManager.hasTask(group) == false
		&& freeAfterAllExecutions.size() > 0) {
	  for (Integer id : freeAfterAllExecutions) {
		Controller.free(id);
	  }
	  freeAfterAllExecutions.clear();
	}

	if (freeAfterExecution.isEmpty() == false) {
	  String taskId = task.getId();
	  Integer controllerId = freeAfterExecution.remove(taskId);
	  if (controllerId != null) {
		Controller.free(controllerId);
	  }
	}
  }

}
