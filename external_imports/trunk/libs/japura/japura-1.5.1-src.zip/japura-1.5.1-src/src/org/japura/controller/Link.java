package org.japura.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * <P>
 * Copyright (C) 2011-2012 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 */
class Link implements Comparator<ControllerModel>{

  private List<ControllerModel> controllers;

  public Link(ControllerModel... array) {
	controllers = new ArrayList<ControllerModel>();
	for (ControllerModel controller : array) {
	  if (controllers.contains(controller) == false) {
		controllers.add(controller);
	  }
	}
	Collections.sort(controllers, this);
  }

  public <E> E get(Class<E> cl) {
	for (ControllerModel controller : controllers) {
	  if (cl.isAssignableFrom(controller.getClass())) {
		return cl.cast(controller);
	  }
	}
	return null;
  }

  @Override
  public int compare(ControllerModel o1, ControllerModel o2) {
	if (o1.getId() > o2.getId()) {
	  return 1;
	} else if (o1.getId() < o2.getId()) {
	  return -1;
	}
	return 0;
  }

  @Override
  public int hashCode() {
	final int prime = 31;
	int result = 1;
	result =
		prime * result + ((controllers == null) ? 0 : controllers.hashCode());
	return result;
  }

  @Override
  public boolean equals(Object obj) {
	if (this == obj)
	  return true;
	if (obj == null)
	  return false;
	if (getClass() != obj.getClass())
	  return false;
	Link other = (Link) obj;
	if (controllers == null) {
	  if (other.controllers != null)
		return false;
	} else if (!controllers.equals(other.controllers))
	  return false;
	return true;
  }

  public boolean contains(ControllerModel controller) {
	return controllers.contains(controller);
  }

  public boolean contains(Class<?> clss) {
	for (ControllerModel controller : controllers) {
	  if (controller.getClass().equals(clss)) {
		return true;
	  }
	}
	return false;
  }

}
