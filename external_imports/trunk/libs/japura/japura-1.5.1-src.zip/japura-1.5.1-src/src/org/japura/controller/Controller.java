package org.japura.controller;

import java.awt.Component;
import java.awt.Container;
import java.awt.Window;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.RootPaneContainer;
import javax.swing.SwingUtilities;

import org.japura.debug.DebugComponent;
import org.japura.debug.DebugWindow;
import org.japura.modal.Modal;
import org.japura.modal.ModalEvent;
import org.japura.modal.ModalListener;
import org.japura.task.Task;
import org.japura.task.TaskManager;
import org.japura.task.TaskSequence;

/**
 * The Controller isolates business logic from presentation.
 * <P>
 * Must implement the following methods:
 * <UL>
 * <LI> <code>getComponent</code> to get the controlled component</LI>
 * <LI> <code>isComponentInstancied</code> to indicates whether the controller is
 * instantiated</LI>
 * </UL>
 * <P>
 * Every instantiated controller is added to a pool of controllers. Through the
 * pool, its possible reach any controller.
 * <P>
 * The state of permanent indicates that the controller can't be removed from
 * the pool unless the parent has been removed.
 * <P>
 * Annotations:
 * <P>
 * <UL>
 * <LI><code>ChildController</code> - defines that a controller can't be
 * instantiated by constructor, only through method <code>createChild</code>.</LI>
 * <LI><code>Singleton</code> - defines a controller as singleton.</LI>
 * </UL>
 * <P>
 * Copyright (C) 2009-2012 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * E
 * 
 * @author Carlos Eduardo Leite de Andrade
 * 
 * @param V
 *          controlled component class
 */
public abstract class Controller<V extends Component> extends
	AbstractController{

  static {
	TaskManager.addListener(ControllerTaskListener.getInstance());
  }

  private static class ModalAllFramesListener implements ModalListener{

	private List<Component> components;

	public ModalAllFramesListener(List<Component> components) {
	  this.components = components;
	}

	@Override
	public void modalClosed(ModalEvent event) {
	  for (Component component : components)
		Modal.closeModal(component);
	}
  }

  private static ControllerPool pool = new ControllerPool();
  private static MockPool mockPool;

  private static ModalPanelFactory modalPanelFactory =
	  new DefaultModalPanelFactory();

  public static boolean hasMockPool() {
	Lock.lock();
	try {
	  return (mockPool != null);
	} finally {
	  Lock.unlock();
	}
  }

  public static MockPool newMockPool() {
	Lock.lock();
	try {
	  mockPool = new MockPool();
	  return mockPool;
	} finally {
	  Lock.unlock();
	}
  }

  public static void removeMockPool() {
	Lock.lock();
	try {
	  mockPool = null;
	} finally {
	  Lock.unlock();
	}
  }

  public static MockPool getMockPool() {
	Lock.lock();
	try {
	  return mockPool;
	} finally {
	  Lock.unlock();
	}
  }

  static AbstractPool getCurrentPool() {
	if (hasMockPool()) {
	  return getMockPool();
	}
	return pool;
  }

  static int getNextId() {
	Lock.lock();
	try {
	  return getCurrentPool().getNextId();
	} finally {
	  Lock.unlock();
	}
  }

  public static boolean existsLink(ControllerModel controller1,
								   ControllerModel controller2) {
	Lock.lock();
	try {
	  return getCurrentPool().existsLink(controller1, controller2);
	} finally {
	  Lock.unlock();
	}
  }

  public static boolean existsLink(ControllerModel controller, Class<?> clss) {
	Lock.lock();
	try {
	  return getCurrentPool().existsLink(controller, clss);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Link two controllers each other. <BR>
   * <BR>
   * The link is undone when one of the controllers is disposed. <BR>
   * <BR>
   * <ul>
   * Is not allowed:
   * <li>more than one link with a same controller.</li>
   * <li>link with two controllers from the same class</li>
   * </ul>
   * 
   * @param controller1
   *          first controller
   * @param controller2
   *          second controller
   */
  public static void link(ControllerModel controller1,
						  ControllerModel controller2) {
	Lock.lock();
	try {
	  getCurrentPool().link(controller1, controller2);
	} finally {
	  Lock.unlock();
	}
  }

  public static void unlink(ControllerModel controller1,
							ControllerModel controller2) {
	Lock.lock();
	try {
	  getCurrentPool().unlink(controller1, controller2);
	} finally {
	  Lock.unlock();
	}
  }

  public static DebugComponent createDebugPanel() {
	DebugControllers component = new DebugControllers();
	DebugComponent.add(component);
	updateDebugComponents();
	return component;
  }

  public static void showDebugWindow() {
	DebugWindow.showDebugWindow(createDebugPanel());
	updateDebugComponents();
  }

  /**
   * Remove a controller from the memory.
   * <P>
   * Controllers defined as permanent, can not be removed unless the parent has
   * been removed.
   * <P>
   * All executions of the tasks will be canceled.
   * 
   * @param id
   *          the controller's identifier
   * 
   * @see #setPermanent(boolean)
   * @see #isPermanent()
   * @see #freeAll()
   * @see #freeAll(Class)
   */
  public static void free(int id) {
	Lock.lock();
	try {
	  getCurrentPool().remove(id);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Remove a controller from the memory.
   * <P>
   * Controllers defined as permanent, can not be removed unless the parent has
   * been removed.
   * 
   * @param id
   *          the controller's identifier
   * @param cancelTaskExecution
   * 
   * @see #setPermanent(boolean)
   * @see #isPermanent()
   * @see #freeAll()
   * @see #freeAll(Class)
   */
  public static void free(int id, boolean cancelTaskExecution) {
	Lock.lock();
	try {
	  getCurrentPool().remove(id, cancelTaskExecution);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Remove from the memory all controllers of a specific group.
   * <P>
   * Controllers defined as permanent, can not be removed unless the parent has
   * been removed.
   * <P>
   * All executions of the tasks will be canceled.
   * 
   * @param groupdId
   * 
   * @see #setPermanent(boolean)
   * @see #isPermanent()
   * @see #free(int)
   */
  public static void freeGroup(int groupdId) {
	Lock.lock();
	try {
	  getCurrentPool().removeGroup(groupdId);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Remove from the memory all controllers of a specific class.
   * <P>
   * Controllers defined as permanent, can not be removed unless the parent has
   * been removed.
   * <P>
   * All executions of the tasks will be canceled.
   * 
   * @param clss
   *          controller's class
   * 
   * @see #setPermanent(boolean)
   * @see #isPermanent()
   * @see #free(int)
   */
  public static void freeAll(Class<?> clss) {
	Lock.lock();
	try {
	  getCurrentPool().removeAll(clss);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Remove from the memory all controllers of a specific class and group.
   * <P>
   * Controllers defined as permanent, can not be removed unless the parent has
   * been removed.
   * <P>
   * All executions of the tasks will be canceled.
   * 
   * @param groupId
   * @param clss
   *          controller's class
   * 
   * @see #setPermanent(boolean)
   * @see #isPermanent()
   * @see #free(int)
   */
  public static void freeAllFromGroup(int groupId, Class<?> clss) {
	Lock.lock();
	try {
	  getCurrentPool().removeAllFromGroup(groupId, clss);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Indicates whether the controller is instantiated.
   * 
   * @param clss
   *          controller's class
   * @return boolean
   */
  public static boolean isInstancied(Class<?> clss) {
	Lock.lock();
	try {
	  return getCurrentPool().isInstancied(clss);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Indicates whether the controller is instantiated in a group.
   * 
   * @param groupId
   * @param clss
   *          controller's class
   * @return boolean
   */
  public static boolean isInstanciedInGroup(int groupId, Class<?> clss) {
	Lock.lock();
	try {
	  return getCurrentPool().isInstanciedInGroup(groupId, clss);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Remove from the memory all controllers.
   * <P>
   * Controllers defined as permanent, can not be removed unless the parent has
   * been removed.
   * <P>
   * All executions of the tasks will be canceled.
   * 
   * @see #setPermanent(boolean)
   * @see #isPermanent()
   * @see #free(int)
   * @see #freeAll(Class)
   */
  public static void freeAll() {
	Lock.lock();
	try {
	  getCurrentPool().removeAll();
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Get the total of controllers of a specific class.
   * 
   * @param clss
   *          the controller's class
   * @return the total of controllers
   */
  public static int count(Class<?> clss) {
	Lock.lock();
	try {
	  return getCurrentPool().count(clss);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Get the first controller of a specific class.
   * <P>
   * If not exists, a controller will be instantiated.
   * 
   * @param <E>
   *          .
   * @param clss
   *          the controller's class
   * @return the controller
   * 
   * @see #get(int, Class)
   */
  public static <E> E get(Class<E> clss) {
	Lock.lock();
	try {
	  return getCurrentPool().get(clss);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Get the controller of a specific class and identifier.
   * 
   * @param id
   *          the controller's identifier
   * @param clss
   *          the controller's class
   * @return the controller or <code>NULL</code> if its not exist.
   * 
   * @see #get(Class)
   */
  public static <E> E get(int id, Class<E> clss) {
	Lock.lock();
	try {
	  return getCurrentPool().get(id, clss);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Get the controller of a specific group and class.
   * 
   * @param groupId
   *          the controller's group identifier
   * @param clss
   *          the controller's class
   * @return the controller or <code>NULL</code> if its not exist.
   * 
   */
  public static <E> E getFromGroup(int groupId, Class<E> clss) {
	Lock.lock();
	try {
	  return getCurrentPool().getFromGroup(groupId, clss);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Get the controller of a specific group, class and identifier.
   * 
   * @param groupId
   *          the controller's group identifier
   * @param id
   *          the controller's identifier
   * @param clss
   *          the controller's class
   * @return the controller or <code>NULL</code> if its not exist.
   * 
   */
  public static <E> E getFromGroup(int groupId, int id, Class<E> clss) {
	Lock.lock();
	try {
	  return getCurrentPool().getFromGroup(groupId, clss);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Get the controller of a specific group and identifier.
   * 
   * @param groupId
   *          the controller's group identifier
   * @param id
   *          the controller's identifier
   * @return the controller or <code>NULL</code> if its not exist.
   * 
   */
  public static ControllerModel getFromGroup(int groupId, int id) {
	Lock.lock();
	try {
	  return getCurrentPool().getFromGroup(groupId, id);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Get the all controllers of a specific group and class.
   * 
   * @param groupId
   *          the controller's group identifier
   * @param clss
   *          the controller's class
   * @return List with the controllers.
   * 
   * @see #get(Class)
   */
  public static <E> List<E> getAllFromGroup(int groupId, Class<E> clss) {
	Lock.lock();
	try {
	  return getCurrentPool().getAllFromGroup(groupId, clss);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Get the all controllers of a specific group.
   * 
   * @param groupId
   *          the controller's group identifier
   * @return List with the controllers.
   * 
   * @see #get(Class)
   */
  public static List<ControllerModel> getAllFromGroup(int groupId) {
	Lock.lock();
	try {
	  return getCurrentPool().getAllFromGroup(groupId);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Get the controller with a specific identifier.
   * 
   * @param id
   *          the controller's identifier
   * @return the controller or <code>NULL</code> if its not exist.
   */
  public static ControllerModel get(int id) {
	Lock.lock();
	try {
	  return getCurrentPool().get(id);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Get all controllers of a specific class.
   * 
   * @param clss
   *          the controller's class
   * @return List with the controllers
   */
  public static <E> List<E> getAll(Class<E> clss) {
	Lock.lock();
	try {
	  return getCurrentPool().getAll(clss);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Get all controllers
   * 
   * @return List with all controllers
   */
  public static List<ControllerModel> getAll() {
	Lock.lock();
	try {
	  return getCurrentPool().getAll();
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Get the first controller of a specific class and controlled component.
   * 
   * @param <E>
   *          .
   * @param clss
   *          the controller's class
   * @param comp
   *          the controlled component
   * @return the controller or <code>NULL</code> if its not exist.
   * @see #get(Class)
   * @see #get(int)
   */
  public static <E> E get(Class<E> clss, Component comp) {
	Lock.lock();
	try {
	  return getCurrentPool().get(clss, comp);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Get the first controller of a specific controlled component.
   * 
   * @param comp
   *          the controlled component
   * @return the controller or <code>NULL</code> if its not exist.
   * @see #get(Class)
   * @see #get(int)
   */
  public static ControllerModel get(Component comp) {
	Lock.lock();
	try {
	  return getCurrentPool().get(comp);
	} finally {
	  Lock.unlock();
	}
  }

  public static void setModalPanelFactory(ModalPanelFactory modalPanelFactory) {
	if (modalPanelFactory != null) {
	  Controller.modalPanelFactory = modalPanelFactory;
	}
  }

  public static ModalPanelFactory getModalPanelFactory() {
	return modalPanelFactory;
  }

  public static boolean contains(ControllerModel controller) {
	Lock.lock();
	try {
	  return getCurrentPool().contains(controller);
	} finally {
	  Lock.unlock();
	}
  }

  /**
   * Show all the instantiated controllers in the pool.
   */
  public static void printAllControllers() {
	Lock.lock();
	try {
	  getCurrentPool().printAllControllers();
	} finally {
	  Lock.unlock();
	}
  }

  public static ControllerModel getRoot(int groupId) {
	Lock.lock();
	try {
	  return getCurrentPool().getRoot(groupId);
	} finally {
	  Lock.unlock();
	}
  }

  public static void updateDebugComponents() {
	if (DebugComponent.exists(DebugControllers.class)) {
	  DebugControllers.Parameter parameter = new DebugControllers.Parameter();
	  DebugComponent.publish(DebugControllers.class, parameter);
	}
  }

  public static void unlink(ControllerModel controller) {
	Lock.lock();
	try {
	  getCurrentPool().unlink(controller);
	} finally {
	  Lock.unlock();
	}
  }

  public static <E> E getFromLink(ControllerModel controllerInLink,
								  Class<E> clss) {
	Lock.lock();
	try {
	  return getCurrentPool().getFromLink(controllerInLink, clss);
	} finally {
	  Lock.unlock();
	}
  }

  private static void fetchHierarchy(Controller<?> parentController,
									 List<Controller<?>> list) {
	Lock.lock();
	try {
	  List<ControllerModel> children = parentController.getChildren();
	  for (ControllerModel child : children) {
		Controller<?> c = (Controller<?>) child;
		list.add(c);
		fetchHierarchy(c, list);
	  }
	} finally {
	  Lock.unlock();
	}
  }

  private static List<RootPaneContainer> getRootPaneContainers(int groupId) {
	List<RootPaneContainer> list = new ArrayList<RootPaneContainer>();
	for (ControllerModel controller : getAll()) {
	  if (controller.getGroupId() == groupId) {
		Controller<?> c = (Controller<?>) controller;
		RootPaneContainer rootPane = c.getRootPaneContainer();
		if (rootPane != null && list.contains(rootPane) == false) {
		  list.add(rootPane);
		}
	  }
	}
	return list;
  }

  /**
   * Get the RootPaneContainer of the specific controller's component.
   * 
   * @param controller
   * @return the RootPaneContainer or <CODE>NULL</CODE> if its not exist.
   */
  private static RootPaneContainer getRootPaneContainer(Controller<?> controller) {
	Component comp = controller.getComponent();
	if (comp != null) {
	  if (comp instanceof RootPaneContainer) {
		return (RootPaneContainer) comp;
	  }

	  for (Container p = comp.getParent(); p != null; p = p.getParent()) {
		if (p instanceof RootPaneContainer) {
		  return (RootPaneContainer) p;
		}
	  }
	}
	return null;
  }

  public static void publishToAll(Message message) {
	Lock.lock();
	try {
	  getCurrentPool().publishToAll(message);
	} finally {
	  Lock.unlock();
	}
  }

  static <E> E newInstance(Class<E> clss) {
	Lock.lock();
	try {
	  return getCurrentPool().newInstance(clss);
	} finally {
	  Lock.unlock();
	}
  }

  static void add(ControllerModel controller) {
	Lock.lock();
	try {
	  getCurrentPool().add(controller);
	} finally {
	  Lock.unlock();
	}
  }

  // ##################################################
  // ##################################################
  // STATIC METHODS: END
  // ##################################################
  // ##################################################

  @Override
  protected void beforeFreeController() {}

  @Override
  protected void afterFreeController() {
	if (isComponentInstancied()) {
	  if (getComponent() instanceof Window) {
		Runnable disposer = new Runnable() {
		  @Override
		  public void run() {
			Window window = (Window) getComponent();
			window.dispose();
		  }
		};
		if (SwingUtilities.isEventDispatchThread()) {
		  disposer.run();
		} else {
		  SwingUtilities.invokeLater(disposer);
		}
	  }
	}
  }

  @Override
  public Window getWindowAncestor() {
	if (isComponentInstancied()) {
	  if (getComponent() instanceof Window) {
		return (Window) getComponent();
	  }
	  Window window = SwingUtilities.getWindowAncestor(getComponent());
	  if (window != null) {
		return window;
	  }
	}
	return null;
  }

  @Override
  public void requestWindowFocus() {
	Window window = getWindowAncestor();
	if (window != null) {
	  window.requestFocus();
	}
  }

  @Override
  public boolean isWindowFocused() {
	Window window = getWindowAncestor();
	if (window != null) {
	  return window.isFocused();
	}
	return false;
  }

  @Override
  public void requestFocus() {
	if (isComponentInstancied()) {
	  getComponent().requestFocus();
	}
  }

  @Override
  public boolean isFocused() {
	if (isComponentInstancied()) {
	  return getComponent().isFocusOwner();
	}
	return false;
  }

  /**
   * Get the controlled component.
   * 
   * @return V the component
   */
  protected abstract V getComponent();

  /**
   * Removes the controller from the memory after the all task executions.
   * 
   * @see #free(int)
   * @see #freeAll()
   * @see #freeAll(Class)
   * @see #beforeFreeController()
   * @see #afterFreeController()
   */
  @Override
  public final void freeAfterExecutions() {
	if (Controller.contains(this)) {
	  ControllerTaskListener.getInstance().freeAfterAllExecutions(this);
	}
  }

  /**
   * Shows a question message modal.
   * 
   * @param title
   *          title for the modal
   * @param question
   *          the question
   * @param yesAction
   *          action for the confirmation button
   * @param noAction
   *          action for the cancel button
   * @see #setModalPanelFactory(ModalPanelFactory)
   */
  @Override
  public void showQuestionModal(String title, String question,
								ModalAction yesAction, ModalAction noAction) {
	addModal(modalPanelFactory.buildQuestionPanel(this, title, question,
		yesAction, noAction));
  }

  /**
   * Shows a question message modal.
   * <P>
   * The cancel button just close the modal.
   * 
   * @param title
   *          title for the modal
   * @param question
   *          the question
   * @param yesAction
   *          action for the confirmation button
   * @see #setModalPanelFactory(ModalPanelFactory)
   */
  @Override
  public void showQuestionModal(String title, String question,
								ModalAction yesAction) {
	addModal(modalPanelFactory.buildQuestionPanel(this, title, question,
		yesAction, null));
  }

  /**
   * Shows a confirmation message modal.
   * 
   * @param title
   *          title for the modal
   * @param question
   *          the question
   * @param confirmAction
   *          action for the confirmation button
   * @param cancelAction
   *          action for the cancel button
   * @see #setModalPanelFactory(ModalPanelFactory)
   */
  @Override
  public void showConfirmationModal(String title, String question,
									ModalAction confirmAction,
									ModalAction cancelAction) {
	addModal(modalPanelFactory.buildConfirmationPanel(this, title, question,
		confirmAction, cancelAction));
  }

  /**
   * Shows a confirmation message modal.
   * <P>
   * The cancel button just close the modal.
   * 
   * @param title
   *          title for the modal
   * @param question
   *          the question
   * @param confirmAction
   *          action for the confirmation button
   * @see #setModalPanelFactory(ModalPanelFactory)
   */
  @Override
  public void showConfirmationModal(String title, String question,
									ModalAction confirmAction) {
	addModal(modalPanelFactory.buildConfirmationPanel(this, title, question,
		confirmAction, null));
  }

  /**
   * Shows a information message modal.
   * 
   * @param title
   *          title for the modal
   * @param info
   *          the information
   * @see #setModalPanelFactory(ModalPanelFactory)
   */
  @Override
  public void showInformationModal(String title, String info) {
	addModal(modalPanelFactory.buildInformationPanel(this, title, info));
  }

  /**
   * Shows a warning message modal.
   * 
   * @param title
   *          title for the modal
   * @param warning
   *          the warning
   * @see #setModalPanelFactory(ModalPanelFactory)
   */
  @Override
  public void showWarningModal(String title, String warning) {
	addModal(modalPanelFactory.buildWarningPanel(this, title, warning));
  }

  /**
   * Shows a error message modal.
   * 
   * @param title
   *          title for the modal
   * @param error
   *          the error
   * @see #setModalPanelFactory(ModalPanelFactory)
   */
  @Override
  public void showErrorModal(String title, String error) {
	addModal(modalPanelFactory.buildErrorPanel(this, title, error));
  }

  @Override
  public void addModal(Component component) {
	addModal(component, null);
  }

  @Override
  public void addModal(Component component, ModalListener listener) {
	addModal(component, listener, null);
  }

  @Override
  public void addModal(Component component, ModalListener listener,
					   Integer modalDepth) {
	RootPaneContainer rootPane = getRootPaneContainer();
	if (rootPane == null) {
	  return;
	}

	if (rootPane instanceof JFrame) {
	  Modal.addModal((JFrame) rootPane, component, listener, modalDepth);
	} else if (rootPane instanceof JDialog) {
	  Modal.addModal((JDialog) rootPane, component, listener, modalDepth);
	} else if (rootPane instanceof JInternalFrame) {
	  Modal
		  .addModal((JInternalFrame) rootPane, component, listener, modalDepth);
	} else {
	  return;
	}

	List<RootPaneContainer> rootPanes = getRootPaneContainers(getGroupId());

	if (getModalGroupName() != null) {
	  String groupName = getModalGroupName().toLowerCase();
	  for (ControllerModel controller : Controller.getAll()) {
		if (controller.getModalGroupName() != null) {
		  String groupNameTemp = controller.getModalGroupName().toLowerCase();
		  if (groupName.equals(groupNameTemp)) {
			Controller<?> c = (Controller<?>) controller;
			RootPaneContainer rootPaneTemp = c.getRootPaneContainer();
			if (rootPaneTemp != null
				&& rootPanes.contains(rootPaneTemp) == false) {
			  rootPanes.add(rootPaneTemp);
			}
		  }
		}
	  }
	}

	rootPanes.remove(rootPane);
	List<Component> list = new ArrayList<Component>();
	for (RootPaneContainer otherRootPane : rootPanes) {
	  JPanel panel = new JPanel();
	  panel.setOpaque(false);
	  list.add(panel);
	  if (otherRootPane instanceof JFrame) {
		Modal.addModal((JFrame) otherRootPane, panel, null, modalDepth);
	  } else if (otherRootPane instanceof JDialog) {
		Modal.addModal((JDialog) otherRootPane, panel, null, modalDepth);
	  }
	}

	if (rootPane instanceof JFrame) {
	  Modal.addListener((JFrame) rootPane, component,
		  new ModalAllFramesListener(list));
	} else if (rootPane instanceof JDialog) {
	  Modal.addListener((JDialog) rootPane, component,
		  new ModalAllFramesListener(list));
	}

  }

  /**
   * Get the current modal component
   * 
   * @return Component
   */
  @Override
  public Component getCurrentModal() {
	RootPaneContainer rootPane = getRootPaneContainer();
	if (rootPane != null) {
	  if (rootPane instanceof JFrame) {
		return Modal.getCurrentModal((JFrame) rootPane);
	  } else if (rootPane instanceof JDialog) {
		return Modal.getCurrentModal((JDialog) rootPane);
	  }
	}
	return null;
  }

  /**
   * Close the current modal.
   */
  public void closeCurrentModal() {
	RootPaneContainer rootPane = getRootPaneContainer();
	if (rootPane != null) {
	  if (rootPane instanceof JFrame) {
		Modal.closeCurrentModal((JFrame) rootPane);
	  } else if (rootPane instanceof JDialog) {
		Modal.closeCurrentModal((JDialog) rootPane);
	  }
	}
  }

  @Override
  public void closeModal(Component component) {
	Modal.closeModal(component);
  }

  @Override
  public void closeAllModals() {
	RootPaneContainer rootPane = getRootPaneContainer();
	if (rootPane != null) {
	  if (rootPane instanceof JFrame) {
		Modal.closeAllModals((JFrame) rootPane);
	  } else if (rootPane instanceof JDialog) {
		Modal.closeAllModals((JDialog) rootPane);
	  }
	}
  }

  @Override
  public boolean hasModal() {
	RootPaneContainer rootPane = getRootPaneContainer();
	if (rootPane == null) {
	  return false;
	}

	if (rootPane instanceof JFrame) {
	  return Modal.hasModal((JFrame) rootPane);
	} else if (rootPane instanceof JDialog) {
	  return Modal.hasModal((JDialog) rootPane);
	}
	return false;
  }

  /**
   * Get the RootPaneContainer of the controlled component.
   * 
   * @return the RootPaneContainer or <CODE>NULL</CODE> if its not exist.
   */
  private RootPaneContainer getRootPaneContainer() {
	return getRootPaneContainer(this);
  }

  /**
   * Executes a task
   * 
   * @param task
   *          the task
   * @param message
   *          message for the task
   * @see org.japura.task.TaskManagerListener
   */
  protected void execute(Task<?> task, String message) {
	submitTask(task, false, message, false);
  }

  protected void execute(Task<?> task) {
	submitTask(task, false, null, false);
  }

  protected void execute(Task<?> task, boolean isAsynchronous, String message) {
	submitTask(task, isAsynchronous, message, false);
  }

  protected void execute(Task<?> task, boolean isAsynchronous) {
	submitTask(task, isAsynchronous, null, false);
  }

  protected void execute(TaskSequence taskSequence) {
	if (taskSequence.hasTask()) {
	  submitTask(taskSequence.getFirstTask(), false, null, false);
	}
  }

  protected void executeAndFree(Task<?> task, String message) {
	submitTask(task, false, message, true);
  }

  protected void executeAndFree(Task<?> task) {
	submitTask(task, false, null, true);
  }

  /**
   * Cancels all task executions from the controllers of the group
   * 
   * @see #execute(Task)
   * @see #execute(Task, String)
   * @see #executeAndFree(Task)
   * @see #executeAndFree(Task, String)
   */
  protected void cancelExecutions() {
	TaskManager.cancel(getGroupId());
  }

  private void submitTask(Task<?> task, boolean isAsynchronous, String message,
						  boolean freeAfterExecution) {
	if (Controller.contains(this) == false) {
	  throw new ControllerException("Controller is not in the pool");
	}
	if (canExecute(task) == false) {
	  return;
	}

	task.setRootModel(getRoot());
	if (message != null) {
	  task.setMessage(message);
	}
	if (freeAfterExecution) {
	  ControllerTaskListener.getInstance().freeAfterExecution(this, task);
	}
	TaskManager.submit(task);
  }

}
