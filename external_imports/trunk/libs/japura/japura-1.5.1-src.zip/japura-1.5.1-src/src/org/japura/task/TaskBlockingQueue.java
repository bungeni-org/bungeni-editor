package org.japura.task;

import java.util.AbstractQueue;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * <P>
 * Copyright (C) 2011-2012 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 */
class TaskBlockingQueue extends AbstractQueue<Runnable> implements
	BlockingQueue<Runnable>{

  private List<Runnable> queue = new ArrayList<Runnable>();

  @Override
  public synchronized Runnable poll() {
	if (queue.size() > 0) {
	  return queue.remove(0);
	}
	return null;
  }

  @Override
  public synchronized Runnable peek() {
	if (queue.size() > 0) {
	  return queue.get(0);
	}
	return null;
  }

  @Override
  public synchronized boolean offer(Runnable e) {
	queue(e);
	return true;
  }

  @Override
  public synchronized void put(Runnable e) throws InterruptedException {
	queue(e);
  }

  @Override
  public synchronized boolean offer(Runnable e, long timeout, TimeUnit unit)
	  throws InterruptedException {
	queue(e);
	return true;
  }

  private synchronized void queue(Runnable e) {
	FutureTaskWrapper<?> fw = (FutureTaskWrapper<?>) e;
	if (fw.getTask().isPriority()) {
	  queue.add(0, e);
	  fw.getTask().clearPriority();
	} else {
	  queue.add(e);
	}
  }

  @Override
  public synchronized Runnable take() throws InterruptedException {
	if (queue.size() > 0) {
	  return queue.remove(0);
	}
	return null;
  }

  @Override
  public synchronized Runnable poll(long timeout, TimeUnit unit)
	  throws InterruptedException {
	return queue.remove(0);
  }

  @Override
  public synchronized int remainingCapacity() {
	return Integer.MAX_VALUE;
  }

  @Override
  public synchronized int drainTo(Collection<? super Runnable> c) {
	c.addAll(queue);
	int count = queue.size();
	queue.clear();
	return count;
  }

  @Override
  public synchronized int drainTo(Collection<? super Runnable> c,
								  int maxElements) {
	int count = 0;
	while (count <= maxElements && queue.size() > 0) {
	  c.add(queue.remove(0));
	  count++;
	}
	queue.removeAll(c);
	return count;
  }

  @Override
  public synchronized Iterator<Runnable> iterator() {
	return queue.iterator();
  }

  @Override
  public synchronized int size() {
	return queue.size();
  }

}
