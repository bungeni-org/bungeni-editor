package org.japura.util;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * Copyright (C) 2011 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 * 
 */
public class WeakList<T> extends AbstractList<T>{

  private final ReferenceQueue<T> queue = new ReferenceQueue<T>();
  private final List<WeakReference<T>> list = new ArrayList<WeakReference<T>>();

  @Override
  public boolean add(T obj) {
	expungeStaleEntries();
	return list.add(new WeakReference<T>(obj, queue));
  }

  @Override
  public T get(int index) {
	expungeStaleEntries();
	return list.get(index).get();
  }

  @Override
  public int size() {
	expungeStaleEntries();
	return list.size();
  }

  @Override
  public T remove(int index) {
	return list.remove(index).get();
  }

  /**
   * Expunge stale entries from the list.
   */
  private void expungeStaleEntries() {
	Object garbagedObj = queue.poll();
	while (garbagedObj != null) {
	  int index = list.indexOf(garbagedObj);
	  if (index != -1) {
		list.remove(index);
	  }
	  garbagedObj = queue.poll();
	}
  }
}
