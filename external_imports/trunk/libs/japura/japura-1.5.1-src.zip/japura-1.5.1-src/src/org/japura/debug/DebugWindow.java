package org.japura.debug;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JDialog;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;

import org.japura.util.WeakList;

/**
 * 
 * Copyright (C) 2011 Carlos Eduardo Leite de Andrade
 * <P>
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * <P>
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * <P>
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <A
 * HREF="www.gnu.org/licenses/">www.gnu.org/licenses/</A>
 * <P>
 * For more information, contact: <A HREF="www.japura.org">www.japura.org</A>
 * <P>
 * 
 * @author Carlos Eduardo Leite de Andrade
 * 
 */
public final class DebugWindow extends JDialog{

  private static Map<Class<?>, Integer> tabsIndex =
	  new HashMap<Class<?>, Integer>();
  private static WeakList<DebugComponent> components =
	  new WeakList<DebugComponent>();
  private static DebugWindow debugWindow;

  static void updateTabTitles() {
	if (components.isEmpty()) {
	  return;
	}
	SwingUtilities.invokeLater(new Runnable() {
	  @Override
	  public void run() {
		if (debugWindow != null) {
		  for (DebugComponent component : components) {
			int index = tabsIndex.get(component.getClass());
			String title = component.getTitle();
			debugWindow.getTabbedPane().setTitleAt(index, title);
		  }
		}
	  }
	});
  }

  public static void showDebugWindow(final DebugComponent component) {
	try {
	  if (tabsIndex.containsKey(component.getClass())) {
		return;
	  }
	  SwingUtilities.invokeLater(new Runnable() {
		@Override
		public void run() {
		  getDebugWindow().setLocation(20, 20);
		  getDebugWindow().setVisible(true);
		  getDebugWindow().addTab(component);
		}
	  });
	} catch (Exception e) {
	  e.printStackTrace();
	}
  }

  private static DebugWindow getDebugWindow() {
	if (debugWindow == null) {
	  debugWindow = new DebugWindow();
	}
	return debugWindow;
  }

  public static void closeDebugWindow() {
	try {
	  if (debugWindow != null) {
		debugWindow.dispose();
		debugWindow = null;
		components.clear();
		tabsIndex.clear();
	  }
	} catch (Exception e) {
	  e.printStackTrace();
	}
  }

  private static final long serialVersionUID = 1966734031063184108L;
  private JTabbedPane tabbedPane;

  private DebugWindow() {
	setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
	addWindowListener(new WindowAdapter() {
	  @Override
	  public void windowClosing(WindowEvent e) {
		DebugWindow.closeDebugWindow();
	  }
	});
	setModal(false);
	setSize(550, 400);
	setTitle("Japura - Debug");
	add(getTabbedPane());
  }

  private JTabbedPane getTabbedPane() {
	if (tabbedPane == null) {
	  tabbedPane = new JTabbedPane();
	}
	return tabbedPane;
  }

  private void addTab(DebugComponent component) {
	if (tabsIndex.containsKey(component.getClass()) == false) {
	  getTabbedPane().addTab("", component);
	  components.add(component);
	  int index = tabbedPane.getTabCount() - 1;
	  tabsIndex.put(component.getClass(), index);
	  getTabbedPane().setSelectedIndex(index);
	}
  }

}
