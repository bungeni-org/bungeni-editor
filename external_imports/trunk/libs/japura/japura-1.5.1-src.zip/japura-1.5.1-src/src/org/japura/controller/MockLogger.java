package org.japura.controller;

public class MockLogger{
  
  static class Log {
	public String taskClass;
	public String taskMethod;
	public String controllerClass;
	public String controllerMethod;
  }

}
